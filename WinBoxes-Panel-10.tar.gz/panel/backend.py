#!/usr/bin/env python3
# ════════════════════════════════════════════════════════════════════════════
#  backend.py — WinBoxes-Panel backend (Python stdlib, rootless-friendly)
#  ----------------------------------------------------------------------------
#  Web cho KHÁCH HÀNG — KHÔNG có admin role, KHÔNG login/token.
#  Khách chỉ thấy VM của mình — KHÔNG thấy node/hostname thông tin.
#
#  REST API (mở): tạo/quản lý VM, console, logs, settings.
#  Scheduler nội bộ: tự chọn node (Best Fit) — khách KHÔNG chọn node.
#  Node↔Hosting: KHÔNG cần key — node chỉ cần biết Hosting URL.
#  KHÔNG chạy QEMU/tải ảnh khi khởi động — chỉ khi API được gọi.
# ════════════════════════════════════════════════════════════════════════════
import os, sys, json, time, hmac, threading, subprocess, shutil, socket, glob, signal
import urllib.request, urllib.error
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs, unquote

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import resource_detect, scheduler

# ── CẤU HÌNH ─────────────────────────────────────────────────────────────────
DATA_DIR   = os.environ.get("WINBOXES_PANEL_DATA", os.path.expanduser("~/.winboxes-panel"))
SCRIPT_DIR = os.environ["WINBOXES_PANEL_SCRIPT_DIR"]
LAUNCHER   = os.environ["WINBOXES_PANEL_LAUNCHER"]
WINBOX     = os.environ.get("WINBOXES_PANEL_WINBOX", "")
MODE       = os.environ.get("WINBOXES_PANEL_MODE", "hosting")
PORT       = int(os.environ.get("WINBOXES_PANEL_PORT", "8090"))
NODE_KEY   = ""  # (deprecated — enrollment key đã bỏ)
WINBOX_VER = "3.2"
NODE_ID    = socket.gethostname() + "-" + str(os.getpid())
# KHÔNG hardcode localhost — node_url chỉ dùng cho hosting→node proxy (nếu cùng mạng).
# Khi node ở máy khác (Colab), hosting không thể reach ngược → VM ops qua push thay vì pull.
NODE_URL   = os.environ.get("WINBOXES_PANEL_NODE_URL", f"http://localhost:{PORT}")
DEBUG      = os.environ.get("WINBOXES_PANEL_DEBUG", "0") in ("1", "true", "yes")
# HTTPS tunnel (localtunnel) — URL công khai + PID để cleanup khi panel dừng.
PUBLIC_URL = os.environ.get("WINBOXES_PANEL_PUBLIC_URL", "")
TUNNEL_PID = os.environ.get("WINBOXES_PANEL_TUNNEL_PID", "")
# Tunnel watchdog: localtunnel client KHÔNG auto-reconnect khi server disconnect.
# Watchdog check health mỗi 60s, restart localtunnel nếu tunnel die.
TUNNEL_LOG      = os.path.join(DATA_DIR, "logs", "tunnel.log")
SUBDOMAIN_FILE  = os.path.join(DATA_DIR, "subdomain")
TUNNEL_PID_FILE = os.path.join(DATA_DIR, "tunnel.pid")
_tunnel_url_lock = threading.Lock()

# ── LOGGING ──────────────────────────────────────────────────────────────────
def log(tag, msg):
    """Log có tag, luôn flush để xem realtime. DEBUG=1 → log thêm HTTP detail."""
    ts = time.strftime("%H:%M:%S")
    print(f"  [{ts}] [{tag}] {msg}", flush=True)

def dbg(tag, msg):
    """Debug log — chỉ in khi DEBUG=1."""
    if DEBUG:
        log(tag, f"DEBUG: {msg}")

VM_DIR    = os.path.join(DATA_DIR, "vm")
STATE_DIR = os.path.join(DATA_DIR, "state")
LOG_DIR   = os.path.join(DATA_DIR, "logs")
NODE_DIR  = os.path.join(DATA_DIR, "nodes")
CFG_DIR   = os.path.join(DATA_DIR, "config")
for d in (VM_DIR, STATE_DIR, LOG_DIR, NODE_DIR, CFG_DIR):
    os.makedirs(d, exist_ok=True)

# PID file để `WinBoxes-Panel.sh --stop` dừng panel mà KHÔNG ảnh hưởng VM
PANEL_PID_FILE = os.path.join(DATA_DIR, "panel.pid")

# Hosting event log (disk) — register/heartbeat/offline/removed
HOSTING_LOG = os.path.join(LOG_DIR, "hosting.log")
def hostlog(msg):
    """Ghi hosting event ra disk + console."""
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{ts}] {msg}"
    log("HOST", msg)
    try:
        with open(HOSTING_LOG, "a") as f:
            f.write(line + "\n")
    except OSError:
        pass

PRESETS = [
    {"key":"win2012","name":"Windows Server 2012 R2","url":"https://archive.org/download/tamnguyen-2012r2/2012.img","uefi":False,"user":"Administrator","pass":"Tamnguyenyt@123"},
    {"key":"win2022","name":"Windows Server 2022","url":"https://archive.org/download/tamnguyen-2022/2022.img","uefi":False,"user":"Administrator","pass":"Tamnguyenyt@123"},
    {"key":"win11","name":"Windows 11 LTSB","url":"https://archive.org/download/win_20260203/win.img","uefi":True,"user":"Admin","pass":"Tam255Z"},
    {"key":"win10ltsb","name":"Windows 10 LTSB 2015","url":"https://archive.org/download/win_20260208/win.img","uefi":False,"user":"Admin","pass":"Tam255Z"},
    {"key":"win10ltsc","name":"Windows 10 LTSC 2023","url":"https://archive.org/download/win_20260215/win.img","uefi":False,"user":"Admin","pass":"Tam255Z"},
    {"key":"win10ltsb2022","name":"Windows 10 LTSB 2022","url":"https://archive.org/download/win_20260717/win.img","uefi":False,"user":"Admin","pass":"Tam255Z"},
]
PRESET_BY_KEY = {p["key"]: p for p in PRESETS}
DEFAULTS = {"theme":"dark","language":"vi","auto_refresh":3,"timeout":30,
            "default_ram":2,"default_cpu":2,"default_disk":40}

# ── HELPERS ──────────────────────────────────────────────────────────────────
def cfg_path(vid): return os.path.join(CFG_DIR, f"vm_{vid}.json")
def state_path(vid): return os.path.join(STATE_DIR, f"vm_{vid}.json")
def log_path(vid): return os.path.join(LOG_DIR, f"vm_{vid}.log")
def load_json(path, default=None):
    try:
        with open(path) as f: return json.load(f)
    except Exception: return default
def save_json(path, obj):
    with open(path, "w") as f: json.dump(obj, f, indent=2)
def list_vm_configs():
    out = []
    for p in sorted(glob.glob(os.path.join(CFG_DIR, "vm_*.json"))):
        c = load_json(p)
        if c: out.append(c)
    return out
def next_vm_id():
    ids = [c["id"] for c in list_vm_configs()]
    return (max(ids) + 1) if ids else 1
def runtime_state(vid): return load_json(state_path(vid), {})
def is_running(vid):
    pidf = os.path.join(VM_DIR, f"vm_{vid}.pid")
    try:
        with open(pidf) as f: pid = int(f.read().strip())
        os.kill(pid, 0); return True
    except Exception: return False

def strip_node_info(vm):
    """Ẩn thông tin node/hostname/image_path khỏi response cho khách hàng."""
    v = dict(vm)
    for k in ("node","node_url","node_vm_id","hostname","environment","is_container",
              "is_rootless","os","arch","image_path"):
        v.pop(k, None)
    return v

# ── SYSTEM INFO (không tiết lộ node internals cho khách) ──────────────────────
def system_info():
    """Thông tin hệ thống cho dashboard khách hàng — KHÔNG lộ node/hostname."""
    return {
        "mode": MODE, "has_kvm": os.path.exists("/dev/kvm"),
        "winbox_available": bool(WINBOX), "python": sys.version.split()[0],
        "data_dir": DATA_DIR, "version": WINBOX_VER,
    }
def metrics():
    snap = resource_detect.snapshot(VM_DIR, WINBOX_VER)
    vms = list_vm_configs()
    return {"cpu_percent": snap["cpu"]["usage_percent"],
            "ram": {"total_mb": snap["ram"]["total"]//1048576, "used_mb": snap["ram"]["used"]//1048576,
                    "percent": snap["ram"]["usage_percent"]},
            "disk": {"total_gb": round(snap["disk"]["total"]/1e9,1), "used_gb": round(snap["disk"]["used"]/1e9,1),
                     "percent": snap["disk"]["usage_percent"]},
            "net": {"rx_mb": round(snap["net"]["rx_bytes"]/1e6,1), "tx_mb": round(snap["net"]["tx_bytes"]/1e6,1)},
            "uptime": snap["uptime"], "vms_total": len(vms),
            "vms_running": sum(1 for c in vms if is_running(c["id"])),
            "load_average": snap["load_average"]}

def vm_monitor(vid):
    st = runtime_state(vid); running = is_running(vid)
    started = st.get("started_at",0)
    up = int(time.time()-started) if running and started else 0
    qmp_status = None
    if running:
        try:
            out = subprocess.run([LAUNCHER,"qmp",str(vid),'{"execute":"query-status"}'],
                                 capture_output=True,text=True,timeout=3).stdout
            for line in out.splitlines():
                if "status" in line: qmp_status = json.loads(line); break
        except: pass
    # KHÔNG trả "node" — khách không thấy
    return {"running":running,"uptime":up,"rdp_port":st.get("rdp_port"),
            "vnc_raw_port":st.get("vnc_raw_port"),"ws_port":st.get("ws_port"),
            "qmp_status":qmp_status,"pid":st.get("pid")}

# ── NODE REGISTRY (nội bộ — KHÔNG expose cho khách) ──────────────────────────
def nodes_path(): return os.path.join(NODE_DIR, "nodes.json")
def load_nodes_dict(): return load_json(nodes_path(), {})
def load_nodes():
    d = load_nodes_dict(); now = time.time()
    out = []
    for nid, n in d.items():
        n = dict(n); n["online"] = (now - n.get("last_seen",0)) < scheduler.OFFLINE_THRESHOLD
        n["id"] = nid; out.append(n)
    return out
def save_node(info):
    d = load_nodes_dict()
    d[info["id"]] = {**d.get(info["id"],{}), **info, "last_seen": time.time()}
    save_json(nodes_path(), d)
def get_node(nid): return load_nodes_dict().get(nid)

# ── COMMAND QUEUE (Hosting → Node, pull model) ───────────────────────────────
# Node ở Colab (behind NAT) → hosting KHÔNG thể push lệnh xuống.
# Thay vàoo: hosting queue lệnh vào disk, node poll lấy + execute + report.
CMD_DIR = os.path.join(DATA_DIR, "commands")
os.makedirs(CMD_DIR, exist_ok=True)

def cmd_dir(node_id): return os.path.join(CMD_DIR, node_id)
def queue_command(node_id, action, vid, params=None):
    """Queue một lệnh cho node. Node sẽ poll và lấy lệnh này."""
    d = cmd_dir(node_id); os.makedirs(d, exist_ok=True)
    cmd_id = f"cmd_{int(time.time()*1000)}"
    cmd = {"id": cmd_id, "node": node_id, "action": action,
           "vid": vid, "params": params or {}, "queued_at": int(time.time())}
    save_json(os.path.join(d, cmd_id + ".json"), cmd)
    return cmd
def get_pending_commands(node_id):
    d = cmd_dir(node_id)
    if not os.path.isdir(d): return []
    out = []
    for f in sorted(glob.glob(os.path.join(d, "*.json"))):
        cmd = load_json(f)
        if cmd: out.append(cmd)
    return out
def ack_command(node_id, cmd_id):
    try: os.remove(os.path.join(cmd_dir(node_id), cmd_id + ".json"))
    except OSError: pass

# ── REMOTE VM STATES (node báo cáo runtime state qua heartbeat) ──────────────
REMOTE_VM_STATES = {}  # {vid: {"running":..,"uptime":..,"rdp_port":..,...}}
REMOTE_VM_LOGS  = {}   # {vid: "log text tail..."} — node gửi qua heartbeat + result
COMMAND_RESULTS = {}   # {vid: {"action":..,"status":..,"result":..,"time":..}}
def update_remote_states(node_id, states):
    """Merge VM states từ node heartbeat vào global remote states."""
    if not states: return
    for vid_str, st in states.items():
        try: vid = int(vid_str)
        except: continue
        REMOTE_VM_STATES[vid] = {**st, "node_id": node_id, "updated": time.time()}

def update_remote_logs(node_id, log_tails):
    """Update remote VM logs từ node heartbeat/result."""
    if not log_tails: return
    for vid_str, log_tail in log_tails.items():
        try: vid = int(vid_str)
        except: continue
        REMOTE_VM_LOGS[vid] = log_tail

def append_vm_log(vid, msg):
    """Append a log line to VM log file (node side — cho local + remote sync).
    ALSO print to stdout (node terminal) để operator thấy real-time."""
    ts = time.strftime("%H:%M:%S")
    line = f"[{ts}] {msg}"
    try:
        with open(log_path(vid), "a") as f:
            f.write(line + "\n")
    except OSError: pass
    # Print to node terminal (stdout) — operator cần thấy download/QEMU logs
    print(f"  [VM#{vid}] {msg}", flush=True)

# ── NODE PROXY (Hosting → Node) ──────────────────────────────────────────────
def node_proxy_http(node_url, path, method="POST", body=None, timeout=30):
    url = node_url.rstrip("/") + path
    headers = {"Content-Type": "application/json"}
    data = json.dumps(body).encode() if body is not None else None
    try:
        req = urllib.request.Request(url, data=data, headers=headers, method=method)
        with urllib.request.urlopen(req, timeout=timeout) as r:
            txt = r.read().decode()
            return r.status, (json.loads(txt) if txt else {})
    except urllib.error.HTTPError as e:
        txt = e.read().decode()
        try: return e.code, json.loads(txt)
        except: return e.code, {"error": txt}
    except Exception as e:
        return 0, {"error": f"node unreachable: {e}"}

# ── VM OPS (local) ───────────────────────────────────────────────────────────
def _resolve_qemu_binary():
    """Tìm QEMU binary — mirror logic trong qemu_launcher.sh resolve_qemu()."""
    for q in (os.environ.get("QEMU_BIN", ""),
             os.path.expanduser("~/qemu-static/bin/qemu-system-x86_64"),
             os.path.expanduser("~/qemu-optimized/bin/qemu-system-x86_64"),
             "/opt/qemu-optimized/bin/qemu-system-x86_64"):
        if q and os.path.isfile(q) and os.access(q, os.X_OK):
            return q
    # PATH lookup
    p = shutil.which("qemu-system-x86_64")
    return p if p else ""

def _ensure_qemu(vid=None):
    """Cài QEMU trên môi trường rootless: tải AppImage + tạo wrapper scripts.
    Mirror logic _rootless_build() từ winboxes-stable-3-2.sh.
    Returns: path to qemu-system-x86_64 wrapper, or '' if failed."""
    prefix = os.path.expanduser("~/qemu-static")
    bin_dir = os.path.join(prefix, "bin")
    appimage_dir = os.path.join(prefix, "share", "qemu-appimage")
    appimage_path = os.path.join(appimage_dir, "QEMU-x86_64.AppImage")
    qemu_wrapper = os.path.join(bin_dir, "qemu-system-x86_64")

    # Đã có rồi → skip
    if os.path.isfile(qemu_wrapper) and os.access(qemu_wrapper, os.X_OK):
        return qemu_wrapper

    def _log(msg):
        if vid is not None:
            append_vm_log(vid, msg)
        print(f"  [QEMU-install] {msg}", flush=True)

    _log("🔧 Cài QEMU (rootless AppImage mode)...")
    os.makedirs(appimage_dir, exist_ok=True)
    os.makedirs(bin_dir, exist_ok=True)

    # AppImage URLs (mirror winboxes-stable-3-2.sh _rootless_download_appimage)
    urls = [
        "https://github.com/pkgforge-dev/QEMU-AppImage/releases/download/11.0.0-1%402026-05-02_1777749420/QEMU-11.0.0-1-anylinux-x86_64.AppImage",
        "https://github.com/lucasmz1/Qemu-AppImage/releases/download/continuous-stable-jammy/QEMU-git-x86_64.AppImage",
    ]

    downloaded = False
    for url in urls:
        _log(f"  Thử tải QEMU AppImage: {url.split('/')[-1]}")
        try:
            # Stream download với progress
            req = urllib.request.Request(url, headers={"User-Agent": "WinBoxes-Panel/1.0"})
            with urllib.request.urlopen(req, timeout=300) as resp:
                total = int(resp.headers.get("Content-Length", 0))
                with open(appimage_path, "wb") as f:
                    downloaded_bytes = 0
                    last_log = 0
                    while True:
                        chunk = resp.read(1024 * 256)
                        if not chunk: break
                        f.write(chunk)
                        downloaded_bytes += len(chunk)
                        # Log progress mỗi ~10MB
                        if total and downloaded_bytes - last_log >= 10 * 1024 * 1024:
                            pct = downloaded_bytes * 100 // total
                            _log(f"    {downloaded_bytes // 1048576}MB / {total // 1048576}MB ({pct}%)")
                            last_log = downloaded_bytes
            if os.path.getsize(appimage_path) > 1024 * 1024:  # > 1MB
                os.chmod(appimage_path, 0o755)
                _log(f"  Download xong: {os.path.getsize(appimage_path) // 1048576}MB")
                downloaded = True
                break
            else:
                _log("  File quá nhỏ — có thể lỗi")
        except Exception as e:
            _log(f"  Tải thất bại: {e}")
            if os.path.exists(appimage_path):
                os.remove(appimage_path)

    if not downloaded:
        _log("❌ Không tải được QEMU AppImage từ bất kỳ URL nào")
        # Thử qua engine winboxes.sh --build
        if WINBOX:
            _log(f"  Thử qua engine: bash {WINBOX} --build")
            try:
                p = subprocess.Popen(
                    ["bash", WINBOX, "--build", "--auto", "--win10ltsb", "--no-vnc"],
                    stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
                for line in p.stdout:
                    _log(f"  [engine] {line.rstrip()}")
                p.wait(timeout=600)
                if os.path.isfile(qemu_wrapper):
                    _log("✅ Engine cài QEMU xong")
                    return qemu_wrapper
            except Exception as e:
                _log(f"  Engine thất bại: {e}")
        return ""

    # Verify AppImage works
    _log("  Verify AppImage...")
    try:
        r = subprocess.run([appimage_path, "--appimage-extract-and-run",
                           "qemu-system-x86_64", "--version"],
                          capture_output=True, text=True, timeout=30)
        if r.returncode != 0:
            _log(f"❌ AppImage verify thất bại: {r.stderr[:200]}")
            return ""
        ver = r.stdout.split("\n")[0] if r.stdout else "unknown"
        _log(f"  AppImage OK: {ver}")
    except Exception as e:
        _log(f"❌ AppImage verify lỗi: {e}")
        return ""

    # Tạo wrapper scripts (mirror _rootless_make_wrappers)
    _log("  Tạo wrapper scripts...")
    for cmd in ["qemu-system-x86_64", "qemu-img", "qemu-nbd", "qemu-io", "qemu-storage-daemon"]:
        wrapper = os.path.join(bin_dir, cmd)
        with open(wrapper, "w") as f:
            f.write(f'#!/bin/sh\nexec "{appimage_path}" --appimage-extract-and-run "{cmd}" "$@"\n')
        os.chmod(wrapper, 0o755)
    _log(f"✅ QEMU sẵn sàng: {qemu_wrapper}")
    _log(f"   Wrappers: {bin_dir}/{{qemu-system-x86_64,qemu-img,...}}")
    return qemu_wrapper

def run_launcher(args, timeout=30, vid=None):
    """Run qemu_launcher.sh, stream output real-time to stdout + VM log.
    vid: nếu có, log mỗi dòng vào append_vm_log (cho node terminal visibility)."""
    cmd = ["bash", LAUNCHER, *args]
    if vid is not None:
        append_vm_log(vid, f"$ {' '.join(args)}")
    try:
        p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                             text=True, env=dict(os.environ))
        out_lines = []
        try:
            for line in p.stdout:
                line = line.rstrip()
                out_lines.append(line)
                # Print real-time to node terminal
                print(f"  [launcher] {line}", flush=True)
                if vid is not None:
                    append_vm_log(vid, f"  {line}")
            p.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            p.kill()
            p.wait()
            msg = f"timeout after {timeout}s"
            out_lines.append(msg)
            if vid is not None: append_vm_log(vid, f"❌ {msg}")
            return 124, "\n".join(out_lines), msg
        out = "\n".join(out_lines)
        return p.returncode, out, ""
    except Exception as e:
        return 1, "", str(e)

def vm_start_local(vid):
    c = load_json(cfg_path(vid))
    if not c: return 404, {"error":"not found"}
    append_vm_log(vid, f"▶ vm_start_local: name={c.get('name','?')} cpu={c['cpu']} ram={c['ram_gb']}GB")
    # KVM check
    has_kvm_access = os.path.exists("/dev/kvm") and os.access("/dev/kvm", os.R_OK | os.W_OK)
    append_vm_log(vid, f"  KVM: {'available' if has_kvm_access else 'NOT available (TCG software emulation)'}")

    # ── 1) Ảnh chưa có → download qua engine (tự cài QEMU + tải ảnh) ──
    if not os.path.exists(c["image_path"]):
        append_vm_log(vid, f"  Ảnh chưa có: {c['image_path']}")
        if c.get("preset_key") and WINBOX:
            append_vm_log(vid, "⚠ Ảnh chưa có — tự động download (engine sẽ cài QEMU nếu cần)...")
            _download_and_start_bg(vid, c)
            return 202, {"status":"downloading",
                         "message":"Ảnh chưa có, đang download. VM sẽ tự khởi động sau."}
        append_vm_log(vid, f"❌ Không có ảnh và không có engine để download (WINBOX={'yes' if WINBOX else 'no'})")
        return 400, {"error":"image not found", "image_path":c["image_path"]}

    # ── 2) Ảnh có rồi → check QEMU, tự cài nếu cần ──
    append_vm_log(vid, f"  Ảnh OK: {c['image_path']}")
    qb = _resolve_qemu_binary()
    if not qb:
        append_vm_log(vid, "  QEMU chưa cài — tự động cài qua engine...")
        qb = _ensure_qemu(vid)
        if not qb:
            append_vm_log(vid, "❌ Không cài được QEMU!")
            return 500, {"error":"qemu not found", "message":"QEMU chưa cài và không cài được"}
    else:
        append_vm_log(vid, f"  QEMU: {qb}")
    args = ["start", str(vid), c["image_path"], str(c["ram_gb"]), str(c["cpu"]),
            str(c.get("rdp_port",3388+vid)), str(c.get("vnc_display",vid-1)),
            str(c.get("ws_port",6000+vid)), c.get("machine","q35"),
            "1" if c.get("uefi") else "0"]
    args += [f"{f['host']}:{f['guest']}" for f in c.get("forwards",[])]
    append_vm_log(vid, f"▶ Start QEMU: cpu={c['cpu']} ram={c['ram_gb']}GB machine={c.get('machine','q35')}")
    rc, out, err = run_launcher(args, timeout=60, vid=vid)
    append_vm_log(vid, f"  QEMU rc={rc}")
    # Set status
    if rc == 0:
        c["status"] = "running"
        c["has_started"] = True
        save_json(cfg_path(vid), c)
        # Setup Tailscale if token provided
        ts_token = c.get("tailscale_token","")
        if ts_token:
            ts_ip = _setup_tailscale(ts_token, vid)
            c["tailscale_ip"] = ts_ip
            save_json(cfg_path(vid), c)
            append_vm_log(vid, f"🔒 Tailscale IPv4: {ts_ip}")
    else:
        c["status"] = "stopped"
        c["has_started"] = True
        save_json(cfg_path(vid), c)
    return (200 if rc==0 else 500), {"rc":rc,"stdout":out[-800:],"stderr":err[-800:],"status":c["status"]}

def _setup_tailscale(auth_token, vid):
    """Install + configure Tailscale. Return IPv4 or empty string."""
    try:
        # Check if tailscale is installed
        if not shutil.which("tailscale"):
            append_vm_log(vid, "⬇ Installing Tailscale...")
            r = subprocess.run(["bash","-c","curl -fsSL https://tailscale.com/install.sh | sh"],
                               capture_output=True, text=True, timeout=60)
            if r.returncode != 0:
                append_vm_log(vid, f"  Tailscale install failed: {r.stderr[:200]}")
                return ""
            append_vm_log(vid, "  Tailscale installed")
        # Start tailscaled if not running
        if not os.path.exists("/var/run/tailscale/tailscaled.sock"):
            subprocess.Popen(["tailscaled","--tun=userspace-networking","--statedir=/tmp/tailscaled"],
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            time.sleep(3)
        # Authenticate
        append_vm_log(vid, f"🔒 Tailscale authenticating...")
        r = subprocess.run(["tailscale","up","--authkey",auth_token,
                            "--hostname",f"winbox-vm-{vid}","--accept-routes"],
                           capture_output=True, text=True, timeout=30)
        if r.returncode != 0:
            append_vm_log(vid, f"  Tailscale auth failed: {r.stderr[:200]}")
            return ""
        # Get IPv4
        r = subprocess.run(["tailscale","ip","-4"], capture_output=True, text=True, timeout=5)
        ip = r.stdout.strip().split("\n")[0] if r.stdout.strip() else ""
        append_vm_log(vid, f"  Tailscale IPv4: {ip}")
        return ip
    except Exception as e:
        append_vm_log(vid, f"  Tailscale error: {e}")
        return ""

def _download_and_start_bg(vid, c):
    """Download QEMU (AppImage/rootless hoặc build/root) + ảnh Windows (aria2) + start QEMU.
    Toàn bộ log → append_vm_log → hiện trong Web UI (SSE) + node terminal."""
    key = c.get("preset_key")
    target = os.path.dirname(c["image_path"])
    preset = PRESET_BY_KEY.get(key)
    url = preset["url"] if preset else ""

    def _bg():
        try:
            append_vm_log(vid, "════════════════════════════════════════")
            append_vm_log(vid, "🚀 Bắt đầu setup VM (download QEMU + ảnh + start)")
            append_vm_log(vid, f"  Preset: {key}")
            append_vm_log(vid, f"  Target ảnh: {c['image_path']}")
            is_rootless = os.getuid() != 0
            append_vm_log(vid, f"  Mode: {'ROOTLESS (AppImage)' if is_rootless else 'ROOT (build/apt)'}")

            # ── Bước 1: Cài QEMU nếu chưa có ──
            qb = _resolve_qemu_binary()
            if not qb:
                append_vm_log(vid, "")
                append_vm_log(vid, "📦 BƯỚC 1/3: Cài QEMU")
                if is_rootless:
                    append_vm_log(vid, "  Rootless → tải QEMU AppImage (~162MB)")
                else:
                    append_vm_log(vid, "  Root → build QEMU tối ưu (PGO/BOLT) hoặc apt install")
                if WINBOX:
                    # Engine tự xử lý: rootless → AppImage, root → build/apt
                    append_vm_log(vid, f"  Engine: {WINBOX}")
                    append_vm_log(vid, f"  Chạy: bash {WINBOX} --build --auto --{key} --no-vnc")
                    p = subprocess.Popen(
                        ["bash", WINBOX, "--build", "--auto", f"--{key}", "--no-vnc"],
                        stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                        cwd=target, env=dict(os.environ), text=True)
                    for line in p.stdout:
                        append_vm_log(vid, f"  [engine] {line.rstrip()}")
                    p.wait()
                    append_vm_log(vid, f"  Engine exit code: {p.returncode}")
                else:
                    # Fallback: tải AppImage trực tiếp
                    qb = _ensure_qemu(vid)
                    if not qb:
                        append_vm_log(vid, "❌ Không cài được QEMU — không thể start VM")
                        c2 = load_json(cfg_path(vid)) or c
                        c2["status"] = "error"; save_json(cfg_path(vid), c2)
                        return
                qb = _resolve_qemu_binary()
                if qb:
                    append_vm_log(vid, f"✅ QEMU sẵn sàng: {qb}")
                else:
                    append_vm_log(vid, "❌ QEMU vẫn chưa có sau engine — không thể start VM")
                    c2 = load_json(cfg_path(vid)) or c
                    c2["status"] = "error"; save_json(cfg_path(vid), c2)
                    return
            else:
                append_vm_log(vid, f"  QEMU đã có: {qb}")

            # ── Bước 2: Tải ảnh Windows nếu chưa có ──
            if not os.path.exists(c["image_path"]):
                append_vm_log(vid, "")
                append_vm_log(vid, "⬇ BƯỚC 2/3: Tải ảnh Windows")
                if WINBOX:
                    # Engine tự cài QEMU + tải ảnh (aria2 nếu có)
                    append_vm_log(vid, f"  Chạy: bash {WINBOX} --auto --{key} --no-vnc")
                    p = subprocess.Popen(
                        ["bash", WINBOX, "--auto", f"--{key}", "--no-vnc"],
                        stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                        cwd=target, env=dict(os.environ), text=True)
                    for line in p.stdout:
                        append_vm_log(vid, f"  [engine] {line.rstrip()}")
                    p.wait()
                    append_vm_log(vid, f"  Engine exit code: {p.returncode}")
                    if os.path.exists(os.path.join(target, "win.img")):
                        shutil.move(os.path.join(target, "win.img"), c["image_path"])
                        append_vm_log(vid, "✅ Ảnh download xong!")
                    else:
                        # Tìm file ảnh khác
                        found = False
                        for f in os.listdir(target):
                            if f.endswith(".img") or f.endswith(".qcow2"):
                                shutil.move(os.path.join(target, f), c["image_path"])
                                append_vm_log(vid, f"✅ Tìm thấy ảnh: {f}")
                                found = True; break
                        if not found:
                            append_vm_log(vid, "❌ Engine không tạo ảnh")
                            c2 = load_json(cfg_path(vid)) or c
                            c2["status"] = "error"; save_json(cfg_path(vid), c2)
                            return
                elif url:
                    # Fallback: tải trực tiếp (ưu tiên aria2)
                    append_vm_log(vid, f"  URL: {url}")
                    if shutil.which("aria2c"):
                        append_vm_log(vid, "  Dùng aria2c (16 connections)")
                        r = subprocess.run(
                            ["aria2c", "-x16", "-s16", "--file-allocation=none",
                             "-o", os.path.basename(c["image_path"]),
                             "-d", target, url],
                            capture_output=True, text=True, timeout=3600)
                        append_vm_log(vid, f"  aria2c rc={r.returncode}")
                    else:
                        append_vm_log(vid, "  Dùng urllib (không có aria2c)")
                        import urllib.request as ur
                        ur.urlretrieve(url, c["image_path"])
                    if os.path.exists(c["image_path"]):
                        append_vm_log(vid, "✅ Ảnh download xong!")
                    else:
                        append_vm_log(vid, "❌ Tải ảnh thất bại")
                        c2 = load_json(cfg_path(vid)) or c
                        c2["status"] = "error"; save_json(cfg_path(vid), c2)
                        return
            else:
                append_vm_log(vid, f"  Ảnh đã có: {c['image_path']}")

            # Kiểm tra ảnh
            if not os.path.exists(c["image_path"]):
                append_vm_log(vid, "❌ Ảnh không tồn tại sau download")
                c2 = load_json(cfg_path(vid)) or c
                c2["status"] = "error"; save_json(cfg_path(vid), c2)
                return

            # ── Bước 3: Start QEMU ──
            append_vm_log(vid, "")
            append_vm_log(vid, "▶ BƯỚC 3/3: Khởi động QEMU")
            args = ["start", str(vid), c["image_path"], str(c["ram_gb"]), str(c["cpu"]),
                    str(c.get("rdp_port",3388+vid)), str(c.get("vnc_display",vid-1)),
                    str(c.get("ws_port",6000+vid)), c.get("machine","q35"),
                    "1" if c.get("uefi") else "0"]
            rc, out, err = run_launcher(args, timeout=60, vid=vid)
            append_vm_log(vid, f"  QEMU rc={rc}")
            if rc == 0:
                append_vm_log(vid, "✅ VM đã khởi động thành công!")
                c2 = load_json(cfg_path(vid)) or c
                c2["status"] = "running"; c2["has_started"] = True
                save_json(cfg_path(vid), c2)
            else:
                append_vm_log(vid, f"❌ QEMU thất bại (rc={rc})")
                c2 = load_json(cfg_path(vid)) or c
                c2["status"] = "stopped"; c2["has_started"] = True
                save_json(cfg_path(vid), c2)
            append_vm_log(vid, "════════════════════════════════════════")
        except Exception as e:
            append_vm_log(vid, f"❌ Lỗi: {e}")
            c2 = load_json(cfg_path(vid)) or c
            c2["status"] = "error"; save_json(cfg_path(vid), c2)
    threading.Thread(target=_bg, daemon=True).start()
    threading.Thread(target=_bg, daemon=True).start()

def vm_stop_local(vid):
    append_vm_log(vid, "⏹ Stopping VM...")
    rc, out, err = run_launcher(["stop", str(vid)], timeout=40, vid=vid)
    append_vm_log(vid, f"  Stop rc={rc}")
    c = load_json(cfg_path(vid))
    if c: c["status"] = "stopped"; save_json(cfg_path(vid), c)
    return (200 if rc==0 else 500), {"rc":rc,"stdout":out,"stderr":err,"status":"stopped"}

def vm_clone_local(vid):
    c = load_json(cfg_path(vid))
    if not c: return 404, {"error":"not found"}
    if is_running(vid): return 409, {"error":"stop vm before clone"}
    new_id = next_vm_id()
    new_img = os.path.join(VM_DIR, f"vm_{new_id}.img")
    try: shutil.copyfile(c["image_path"], new_img)
    except Exception as e: return 500, {"error":str(e)}
    nc = dict(c); nc["id"]=new_id; nc["name"]=c["name"]+" (clone)"; nc["image_path"]=new_img
    nc["rdp_port"]=3388+new_id; nc["vnc_display"]=new_id-1; nc["ws_port"]=6000+new_id
    nc["created_at"]=int(time.time()); nc.pop("node", None)
    save_json(cfg_path(new_id), nc)
    return 200, strip_node_info(nc)

def vm_delete_local(vid):
    if is_running(vid): vm_stop_local(vid)
    for p in (cfg_path(vid), state_path(vid)):
        try: os.remove(p)
        except: pass
    return 200, {"ok":True}

def vm_download_local(vid):
    c = load_json(cfg_path(vid))
    if not c: return 404, {"error":"not found"}
    if not WINBOX: return 503, {"error":"winboxes.sh not available"}
    key = c.get("preset_key")
    if not key: return 400, {"error":"not a preset vm"}
    job_dir = os.path.join(DATA_DIR, "jobs"); os.makedirs(job_dir, exist_ok=True)
    logf = os.path.join(job_dir, f"download_{vid}_{int(time.time())}.log")
    target = os.path.dirname(c["image_path"])
    def _bg():
        try:
            with open(logf,"w") as f:
                p = subprocess.Popen(["bash", WINBOX, "--auto", f"--{key}", "--no-vnc"],
                                     stdout=f, stderr=subprocess.STDOUT, cwd=target, env=dict(os.environ))
                p.wait()
            if os.path.exists(os.path.join(target, "win.img")):
                shutil.move(os.path.join(target,"win.img"), c["image_path"])
        except Exception as e:
            with open(logf,"a") as f: f.write(f"\nERROR: {e}\n")
    threading.Thread(target=_bg, daemon=True).start()
    return 202, {"job_log": logf, "status":"started"}

# ── SCHEDULER-INTEGRATED VM CREATE ───────────────────────────────────────────
def vm_create_scheduled(b):
    vid = next_vm_id()
    key = b.get("preset_key","")
    preset = PRESET_BY_KEY.get(key)
    uefi = preset["uefi"] if preset else b.get("uefi",False)
    img = b.get("image_path") or os.path.join(VM_DIR, f"vm_{vid}.img")
    req_cpu = int(b.get("cpu", DEFAULTS["default_cpu"]))
    req_ram_gb = int(b.get("ram_gb", DEFAULTS["default_ram"]))
    req_disk_gb = int(b.get("disk_gb", DEFAULTS["default_disk"]))
    c = {
        "id": vid, "name": b.get("name", f"VM-{vid}"),
        "image_path": img, "preset_key": key, "uefi": uefi,
        "ram_gb": req_ram_gb, "cpu": req_cpu, "disk_gb": req_disk_gb,
        "machine": b.get("machine","q35"), "forwards": b.get("forwards",[]),
        "rdp_port": 3388+vid, "vnc_display": vid-1, "ws_port": 6000+vid,
        "created_at": int(time.time()), "node": None,
        "tailscale_token": b.get("tailscale_token",""),
        "tailscale_ip": "",
        "status": "creating",
    }
    if MODE == "hosting":
        # Hosting mode: BẮT BUỘC route VM tới node đã đăng ký.
        online_nodes = [n for n in load_nodes() if n.get("online") and n.get("cpu")]
        if not online_nodes:
            return 503, {"error":"no_node",
                         "message":"Chưa có Node nào online. Hãy chạy WinBoxes ở VM Mode "
                                   "trên máy khác và đăng ký lên Hosting này.",
                         "scheduled":False}
        try:
            chosen = scheduler.schedule(online_nodes, req_cpu,
                                        req_ram_gb*1024**3, req_disk_gb*1024**3)
        except scheduler.SchedulerError as e:
            return 503, {"error":"no_node","message":str(e),"scheduled":False}
        c["node"] = chosen["id"]
        # Lưu config trên hosting (hiển thị dashboard) + queue lệnh "create" cho node
        save_json(cfg_path(vid), c)
        queue_command(chosen["id"], "create", vid, {"config": c})
        hostlog(f"📤 VM #{vid} '{c['name']}' queued for node '{chosen['id']}' (create)")
    else:
        # VM mode: tạo VM nội bộ trên node này
        c["node"] = "local"
        save_json(cfg_path(vid), c)
    return 201, strip_node_info(c)

# ── VM OPS ROUTER ─────────────────────────────────────────────────────────────
def vm_op(vid, op, extra=None):
    c = load_json(cfg_path(vid))
    if not c: return 404, {"error":"not found"}
    node = c.get("node", "local")
    if node in ("local", None) or node == NODE_ID:
        # ── Local execution ──
        if op=="start": return vm_start_local(vid)
        if op=="stop": return vm_stop_local(vid)
        if op=="restart": vm_stop_local(vid); time.sleep(2); return vm_start_local(vid)
        if op=="download": return vm_download_local(vid)
        if op=="clone": return vm_clone_local(vid)
        if op=="delete": return vm_delete_local(vid)
        if op=="rename":
            c["name"]=extra.get("name",c["name"]); save_json(cfg_path(vid),c); return 200, strip_node_info(c)
        if op=="resize":
            rc,o,e=run_launcher(["resize",str(vid),c["image_path"],extra.get("size","+5G")],timeout=120,vid=vid)
            return (200 if rc==0 else 500),{"rc":rc,"output":o,"error":e,"status":c.get("status","stopped")}
        if op=="snapshot":
            rc,o,e=run_launcher(["snapshot",str(vid),extra.get("action","list"),
                                 extra.get("name",""),c["image_path"]],timeout=15,vid=vid)
            return (200 if rc==0 else 500),{"rc":rc,"output":o,"error":e,"status":c.get("status","stopped")}
        return 404, {"error":"unknown op"}
    else:
        # ── Remote node: queue command (pull model) ──
        # Node ở Colab (behind NAT) → hosting KHÔNG thể push HTTP trực tiếp.
        # Queue lệnh vào disk, node sẽ poll lấy + execute + report.
        n = get_node(node)
        if not n and op != "delete": return 502, {"error":"node unavailable"}
        if op == "delete":
            # Delete: queue cho node xóa image + state, hosting xóa config ngay
            queue_command(node, "delete", vid, {})
            hostlog(f"📤 VM #{vid} op='delete' queued for node '{node}'")
            # Hosting also removes its own config + state
            try: os.remove(cfg_path(vid))
            except OSError: pass
            try: os.remove(state_path(vid))
            except OSError: pass
            REMOTE_VM_STATES.pop(vid, None)
            REMOTE_VM_LOGS.pop(vid, None)
            COMMAND_RESULTS.pop(vid, None)
            return 200, {"ok":True, "deleted":True}
        queue_command(node, op, vid, extra or {})
        hostlog(f"📤 VM #{vid} op='{op}' queued for node '{node}'")
        return 202, {"ok":True, "status":"queued", "node":node, "op":op, "vid":vid}

# ════════════════════════════════════════════════════════════════════════════
#  HTTP HANDLER — MỞ cho khách hàng, node_auth nội bộ cho register/heartbeat
# ════════════════════════════════════════════════════════════════════════════
class Handler(BaseHTTPRequestHandler):
    server_version = "WinBoxes-Panel/1.0"
    def log_message(self, *a): pass

    def _send(self, code, obj=None, ctype="application/json", body=None):
        if body is None:
            body = json.dumps(obj).encode() if obj is not None else b""
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control","no-store")
        self.send_header("Access-Control-Allow-Origin","*")
        self.end_headers()
        if self.command != "HEAD":
            try: self.wfile.write(body)
            except: pass

    def _body(self):
        ln = int(self.headers.get("Content-Length",0))
        if not ln: return {}
        try: return json.loads(self.rfile.read(ln))
        except: return {}

    def do_OPTIONS(self): self._send(200, body=b"")

    # ── GET (khách hàng — mở) ──────────────────────────────────────────────
    def do_GET(self):
        u = urlparse(self.path); p = u.path
        if p == "/" or p == "/index.html": return self._serve_static("static/index.html","text/html")
        if p.startswith("/static/"): return self._serve_static(unquote(p[1:]))
        if p.startswith("/console/"): return self._serve_static("static/console.html","text/html")
        if p == "/api/presets": return self._send(200, PRESETS)
        if p == "/api/system": return self._send(200, {**system_info(), "metrics": metrics()})
        if p == "/api/settings": return self._send(200, load_json(os.path.join(DATA_DIR,"settings.json"), DEFAULTS))
        if p == "/api/vm":
            vms = []
            for c in list_vm_configs():
                v = {**c, "runtime": runtime_state(c["id"])}
                node = c.get("node", "local")
                if node in ("local", None) or node == NODE_ID:
                    v["running"] = is_running(c["id"])
                    if v["running"]:
                        v["status"] = "running"
                    elif c.get("has_started"):
                        v["status"] = "stopped"
                    else:
                        v["status"] = c.get("status", "creating")
                else:
                    rst = REMOTE_VM_STATES.get(c["id"], {})
                    v["running"] = rst.get("running", False)
                    v["status"] = rst.get("status", "creating")
                    v["tailscale_ip"] = rst.get("tailscale_ip", c.get("tailscale_ip",""))
                vms.append(strip_node_info(v))
            return self._send(200, vms)
        if p == "/api/scheduler/can-fit":
            # Khách xem có thể tạo VM cấu hình X không — KHÔNG lộ node nào
            q = parse_qs(u.query)
            try: cpu=int(q.get("cpu",["2"])[0]); ram=int(q.get("ram",["2"])[0]); disk=int(q.get("disk",["40"])[0])
            except: return self._send(400,{"error":"bad params"})
            nodes = [n for n in load_nodes() if n.get("online") and n.get("cpu")]
            try:
                scheduler.schedule(nodes, cpu, ram*1024**3, disk*1024**3)
                return self._send(200, {"ok":True,"message":"Sẵn sàng cấp phát"})
            except scheduler.SchedulerError as e:
                return self._send(200, {"ok":False,"message":str(e)})
        if p == "/api/nodes":
            # Hosting dashboard — list tất cả node với status online/offline
            nodes = load_nodes()
            now = time.time()
            out = []
            for n in nodes:
                online = (now - n.get("last_seen", 0)) < scheduler.OFFLINE_THRESHOLD
                cpu = n.get("cpu", {})
                ram = n.get("ram", {})
                disk = n.get("disk", {})
                out.append({
                    "id": n.get("id", "?"),
                    "hostname": n.get("hostname", "?"),
                    "environment": n.get("environment", "?"),
                    "online": online,
                    "last_seen": n.get("last_seen", 0),
                    "last_seen_ago": int(now - n.get("last_seen", 0)),
                    "cpu": {
                        "total": cpu.get("total", 0),
                        "free": cpu.get("free", 0),
                        "usage_percent": cpu.get("usage_percent", 0),
                        "source": cpu.get("source", "?"),
                    },
                    "ram": {
                        "total_mb": ram.get("total", 0) // 1048576,
                        "free_mb": ram.get("free", 0) // 1048576,
                        "usage_percent": ram.get("usage_percent", 0),
                        "source": ram.get("source", "?"),
                    },
                    "disk": {
                        "total_gb": round(disk.get("total", 0) / 1e9, 1),
                        "free_gb": round(disk.get("free", 0) / 1e9, 1),
                        "usage_percent": disk.get("usage_percent", 0),
                        "source": disk.get("source", "?"),
                    },
                    "vm_count": n.get("vm_count", 0),
                    "load_average": n.get("load_average", [0, 0, 0]),
                    "uptime": n.get("uptime", 0),
                    "os": n.get("os", {}),
                    "arch": n.get("arch", "?"),
                    "is_container": n.get("is_container", False),
                    "is_rootless": n.get("is_rootless", False),
                    "winbox_version": n.get("winbox_version", "?"),
                })
            return self._send(200, out)
        # /api/vm/<id>/...
        parts = [x for x in p.split("/") if x]
        if len(parts)>=3 and parts[0]=="api" and parts[1]=="vm":
            try: vid = int(parts[2])
            except: return self._send(400, {"error":"bad id"})
            c = load_json(cfg_path(vid))
            if not c: return self._send(404, {"error":"not found"})
            if len(parts)==3:
                node = c.get("node", "local")
                if node in ("local", None) or node == NODE_ID:
                    c["running"]=is_running(vid); c["runtime"]=runtime_state(vid)
                    if c["running"]:
                        c["status"] = "running"
                    elif c.get("has_started"):
                        c["status"] = "stopped"
                    else:
                        c["status"] = c.get("status", "creating")
                else:
                    rst = REMOTE_VM_STATES.get(vid, {})
                    c["running"]=rst.get("running", False); c["runtime"]=rst
                    c["status"] = rst.get("status", "creating")
                    c["tailscale_ip"] = rst.get("tailscale_ip", c.get("tailscale_ip",""))
                return self._send(200, strip_node_info(c))
            sub = parts[3]
            if sub=="status": return self._send(200, runtime_state(vid))
            if sub=="monitor": return self._send(200, vm_monitor(vid))
            if sub=="result":
                # Frontend poll command result sau khi queue
                return self._send(200, COMMAND_RESULTS.get(vid, {"status":"pending"}))
            if sub=="log":
                # Lấy log content (local hoặc remote)
                c = load_json(cfg_path(vid))
                node = c.get("node","local") if c else "local"
                if node in ("local", None) or node == NODE_ID:
                    try:
                        with open(log_path(vid),"r") as f: content=f.read()
                        return self._send(200, {"log":content})
                    except: return self._send(200, {"log":""})
                else:
                    return self._send(200, {"log":REMOTE_VM_LOGS.get(vid,"")})
            if sub=="console":
                st=runtime_state(vid)
                return self._send(200, {"ws_port":st.get("ws_port",6000+vid),
                                        "vnc_raw_port":st.get("vnc_raw_port",5900+vid-1),
                                        "running":is_running(vid)})
            if sub=="snapshots":
                c=load_json(cfg_path(vid))
                rc,o,e=run_launcher(["snapshot",str(vid),"list","",c["image_path"] if c else ""],timeout=5)
                return self._send(200, {"output":o})
            if sub=="logs": return self._sse_logs(vid)
            return self._send(404, {"error":"unknown sub"})
        return self._send(404, {"error":"not found"})

    # ── POST ──────────────────────────────────────────────────────────────
    def do_POST(self):
        u = urlparse(self.path); p = u.path; b = self._body()
        # ── Node↔Hosting (register/heartbeat — KHÔNG cần key) ──────────────
        if p == "/api/node/register":
            nid = b.get("id", "?")
            host = b.get("hostname", "?")
            env = b.get("environment", "?")
            cpu = b.get("cpu", {})
            ram = b.get("ram", {})
            disk = b.get("disk", {})
            dbg("HOST", f"Incoming registration: id={nid} host={host} env={env}")
            # Valid — log chi tiết
            hostlog(f"📥 Incoming Registration:")
            hostlog(f"   Node ID   : {nid}")
            hostlog(f"   Hostname  : {host}")
            hostlog(f"   Environment: {env}")
            hostlog(f"   CPU       : {cpu.get('total',0)} core ({cpu.get('source','?')})")
            hostlog(f"   RAM       : {ram.get('total',0)//1048576} MB ({ram.get('source','?')})")
            hostlog(f"   Disk      : {disk.get('total',0)//1073741824} GB ({disk.get('source','?')})")
            save_node(b)
            hostlog(f"✅ Registration SUCCESS — Node '{nid}' added to registry + scheduler")
            return self._send(200, {"ok":True, "registered":nid, "added_to_scheduler":True})

        if p == "/api/node/heartbeat":
            nid = b.get("id", "?")
            d = load_nodes_dict()
            if nid not in d:
                # Node chưa register → tự register qua heartbeat (recovery)
                hostlog(f"🔄 Heartbeat from unregistered node '{nid}' — auto-registering")
                save_node(b)
                hostlog(f"✅ Node '{nid}' recovered (auto-registered via heartbeat)")
                # Nhận VM states + logs từ node
                update_remote_states(nid, b.get("vm_states"))
                update_remote_logs(nid, b.get("vm_log_tails"))
                return self._send(200, {"ok":True, "recovered":True})
            d[nid] = {**d[nid], **b, "last_seen": time.time(), "online": True}
            save_json(nodes_path(), d)
            # Nhận VM states + logs từ node
            update_remote_states(nid, b.get("vm_states"))
            update_remote_logs(nid, b.get("vm_log_tails"))
            dbg("HOST", f"Heartbeat OK: {nid} "
                f"cpu={b.get('cpu',{}).get('free',0)} ram={b.get('ram',{}).get('free',0)//1048576}MB "
                f"vm={b.get('vm_count',0)}")
            return self._send(200, {"ok":True})

        if p == "/api/node/poll":
            # Node poll lấy pending commands
            nid = b.get("id", "?")
            cmds = get_pending_commands(nid)
            if cmds:
                dbg("HOST", f"Node '{nid}' polled: {len(cmds)} command(s) pending")
            return self._send(200, {"commands": cmds})

        if p == "/api/node/result":
            # Node báo kết quả thực thi command
            nid = b.get("id", "?")
            cmd_id = b.get("cmd_id", "?")
            action = b.get("action", "?")
            vid = b.get("vid", 0)
            status = b.get("status", "unknown")
            result = b.get("result", {})
            ack_command(nid, cmd_id)
            hostlog(f"📥 Result from '{nid}': VM #{vid} {action} → {status}")
            # Lưu command result để frontend poll
            try: vid_int = int(vid)
            except: vid_int = 0
            COMMAND_RESULTS[vid_int] = {"action":action, "status":status,
                                         "result":result, "time":time.time()}
            # Cập nhật remote VM state + logs
            if "running" in result:
                REMOTE_VM_STATES[vid_int] = {**result, "node_id": nid, "updated": time.time()}
            if "log_tail" in result:
                update_remote_logs(nid, {str(vid_int): result["log_tail"]})
            return self._send(200, {"ok":True})

        if p == "/api/vm/internal/create":
            vid = next_vm_id(); c = dict(b); c["id"]=vid; c["node"]="local"
            save_json(cfg_path(vid), c); return self._send(201, {"id":vid,"ok":True})
        # ── Customer API (mở — không auth) ──
        if p == "/api/vm": return self._send(*vm_create_scheduled(b))
        if p == "/api/settings":
            save_json(os.path.join(DATA_DIR,"settings.json"), {**DEFAULTS, **b}); return self._send(200, {"ok":True})
        parts = [x for x in p.split("/") if x]
        if len(parts)>=4 and parts[0]=="api" and parts[1]=="vm":
            try: vid=int(parts[2])
            except: return self._send(400, {"error":"bad id"})
            sub = parts[3]
            op_map = {"start":"start","stop":"stop","restart":"restart","rename":"rename"}
            if sub in op_map: return self._send(*vm_op(vid, op_map[sub], b))
            return self._send(404,{"error":"unknown sub"})
        return self._send(404, {"error":"not found"})

    def do_DELETE(self):
        parts=[x for x in urlparse(self.path).path.split("/") if x]
        if len(parts)==3 and parts[0]=="api" and parts[1]=="vm":
            try: vid=int(parts[2])
            except: return self._send(400,{"error":"bad id"})
            return self._send(*vm_op(vid,"delete"))
        return self._send(404,{"error":"not found"})

    # ── SSE logs ─────────────────────────────────────────────────────────────
    def _sse_logs(self, vid):
        self.send_response(200)
        self.send_header("Content-Type","text/event-stream")
        self.send_header("Cache-Control","no-cache")
        self.send_header("Connection","keep-alive")
        self.end_headers()

        # Check if VM is remote (hosting mode serving logs for a node VM)
        c = load_json(cfg_path(vid))
        is_remote = c and c.get("node") not in ("local", None) and c["node"] != NODE_ID

        if is_remote:
            # Remote VM — serve from REMOTE_VM_LOGS (synced via heartbeat)
            sent_len = 0
            end = time.time()+60
            while time.time()<end:
                try:
                    log_text = REMOTE_VM_LOGS.get(vid, "")
                    if len(log_text) > sent_len:
                        new_part = log_text[sent_len:]
                        for ln in new_part.splitlines():
                            self.wfile.write(f"data: {ln}\n\n".encode()); self.wfile.flush()
                        sent_len = len(log_text)
                    else:
                        self.wfile.write(b": ping\n\n"); self.wfile.flush()
                except (BrokenPipeError, ConnectionResetError): break
                time.sleep(2)  # Remote logs update every 5s via heartbeat
            return

        # Local VM — read from log file
        path = log_path(vid); pos = 0
        try:
            if os.path.exists(path):
                with open(path,"rb") as f: data=f.read()
                for ln in data.splitlines()[-50:]:
                    self.wfile.write(f"data: {ln.decode(errors='replace')}\n\n".encode()); self.wfile.flush()
                pos=len(data)
        except: pass
        end = time.time()+60
        while time.time()<end:
            try:
                if os.path.exists(path):
                    with open(path,"rb") as f:
                        f.seek(pos); chunk=f.read()
                    if chunk:
                        for ln in chunk.splitlines():
                            self.wfile.write(f"data: {ln.decode(errors='replace')}\n\n".encode()); self.wfile.flush()
                        pos+=len(chunk)
                    else:
                        self.wfile.write(b": ping\n\n"); self.wfile.flush()
                else:
                    self.wfile.write(b": waiting\n\n"); self.wfile.flush()
            except (BrokenPipeError, ConnectionResetError): break
            time.sleep(0.8)

    def _serve_static(self, rel, ctype=None):
        path = os.path.join(SCRIPT_DIR, "panel", rel.replace("/", os.sep))
        if not os.path.isfile(path): return self._send(404, {"error":"file not found","path":rel})
        if ctype is None:
            ext = os.path.splitext(path)[1].lower()
            ctype = {".html":"text/html",".js":"application/javascript",
                     ".css":"text/css",".png":"image/png",".svg":"image/svg+xml"}.get(ext,"application/octet-stream")
        with open(path,"rb") as f: body=f.read()
        self._send(200, body=body, ctype=ctype)

# ════════════════════════════════════════════════════════════════════════════
#  VM MODE: Node Agent — Register + Heartbeat với retry/backoff
#  ----------------------------------------------------------------------------
#  Kiến trúc: Node (Colab/VPS) → push → Hosting (Neurodesk) qua URL công khai.
#  KHÔNG dùng localhost. Node tự đăng ký, gửi heartbeat 5s, retry exponential.
#  Hosting restart / mạng rớt → node tự re-register, KHÔNG cần restart.
# ════════════════════════════════════════════════════════════════════════════

def _build_node_payload():
    """Build full node payload từ resource_detect — gửi cho register + heartbeat."""
    snap = resource_detect.snapshot(VM_DIR, WINBOX_VER)
    # Thu thập VM states để báo cáo cho hosting (cho dashboard)
    vm_states = {}
    vm_log_tails = {}
    for c in list_vm_configs():
        vid = c["id"]
        rst = runtime_state(vid)
        running = is_running(vid)
        # Determine status: creating / running / stopped / downloading
        if running:
            status = "running"
        elif c.get("has_started"):
            status = "stopped"
        else:
            status = c.get("status", "creating")
        vm_states[str(vid)] = {
            "running": running,
            "status": status,
            "uptime": int(time.time() - rst.get("started_at", 0)) if running and rst.get("started_at") else 0,
            "rdp_port": rst.get("rdp_port", c.get("rdp_port")),
            "ws_port": rst.get("ws_port", c.get("ws_port")),
            "pid": rst.get("pid"),
            "tailscale_ip": c.get("tailscale_ip", ""),
        }
        # Gửi log tail (4KB cuối) cho mỗi VM
        try:
            lp = log_path(vid)
            if os.path.exists(lp):
                with open(lp, "r") as f:
                    vm_log_tails[str(vid)] = f.read()[-4096:]
        except: pass
    return {
        "id": NODE_ID,
        "hostname": socket.gethostname(),
        "url": NODE_URL,
        "environment": snap["environment"],
        "is_container": snap["is_container"], "is_rootless": snap["is_rootless"],
        "cpu": snap["cpu"], "ram": snap["ram"], "disk": snap["disk"],
        "load_average": snap["load_average"], "net": snap["net"],
        "vm_count": snap["vm_count"], "uptime": snap["uptime"],
        "os": snap["os"], "arch": snap["arch"],
        "winbox_version": snap["winbox_version"],
        "online": True, "timestamp": int(time.time()),
        "vm_states": vm_states,
        "vm_log_tails": vm_log_tails,
    }

def _http_post_json(url, body, tag="HTTP"):
    """
    POST JSON tới url. Trả (ok, status, response_body).
    Log đầy đủ lỗi: HTTP status, timeout, connection refused, DNS, TLS.
    """
    data = json.dumps(body).encode()
    headers = {"Content-Type": "application/json"}
    if DEBUG:
        dbg(tag, f"POST {url}")
        dbg(tag, f"Headers: {headers}")
        dbg(tag, f"Body keys: {list(body.keys())}")
        dbg(tag, f"Body: {json.dumps(body)[:500]}")
    try:
        req = urllib.request.Request(url, data=data, headers=headers, method="POST")
        with urllib.request.urlopen(req, timeout=15) as r:
            txt = r.read().decode()
            resp = json.loads(txt) if txt else {}
            if DEBUG:
                dbg(tag, f"Response {r.status}: {json.dumps(resp)[:300]}")
            return True, r.status, resp
    except urllib.error.HTTPError as e:
        txt = ""
        try: txt = e.read().decode()
        except: pass
        code_map = {401:"401 Unauthorized", 403:"403 Forbidden", 404:"404 Not Found",
                    500:"500 Internal Server Error"}
        reason = code_map.get(e.code, f"HTTP {e.code}")
        log(tag, f"❌ {reason} — {txt[:200]}")
        return False, e.code, {"error": txt}
    except urllib.error.URLError as e:
        cause = e.reason if hasattr(e, "reason") else str(e)
        if "Name or service not known" in str(cause) or "nodename" in str(cause):
            log(tag, f"❌ DNS Error — không phân giải được hostname: {url}")
        elif "Connection refused" in str(cause):
            log(tag, f"❌ Connection Refused — hosting không chạy hoặc sai port: {url}")
        elif "timed out" in str(cause).lower():
            log(tag, f"❌ Timeout — hosting không phản hồi trong 15s: {url}")
        elif "certificate" in str(cause).lower() or "ssl" in str(cause).lower():
            log(tag, f"❌ TLS/SSL Error — chứng chỉ không hợp lệ: {cause}")
        else:
            log(tag, f"❌ Connection Error: {cause}")
        return False, 0, {"error": str(cause)}
    except Exception as e:
        log(tag, f"❌ Unexpected error: {type(e).__name__}: {e}")
        return False, 0, {"error": str(e)}

def vm_mode_agent_loop():
    """
    Node Agent — chạy nền khi MODE=vm.
    1. Đọc hosting URL từ file (KHÔNG cần enrollment key)
    2. Register (POST /api/node/register) với full payload
    3. Heartbeat 5s (POST /api/node/heartbeat)
    4. Retry exponential: 5, 10, 20, 40, 60s — không thoát
    5. Hosting online lại → tự re-register, không cần restart
    """
    hf = os.environ.get("WINBOXES_PANEL_HOSTING_FILE")
    if not hf or not os.path.exists(hf):
        log("NODE", "Không có hosting file — chạy VM mode độc lập (standalone).")
        return
    try:
        with open(hf) as f:
            host_url = f.readline().strip()
    except Exception as e:
        log("NODE", f"❌ Không đọc được hosting file ({hf}): {e}")
        return
    if not host_url:
        log("NODE", f"❌ Hosting file thiếu URL (file={hf})")
        return

    threading.Thread(target=_agent_thread, args=(host_url,), daemon=True).start()

def _execute_command(cmd):
    """Execute một command từ hosting queue. Trả (status, result)."""
    action = cmd.get("action", "")
    vid = cmd.get("vid", 0)
    params = cmd.get("params", {})
    log("NODE", f"  ▶ Executing: {action} VM #{vid}")

    try:
        vid = int(vid)
    except (ValueError, TypeError):
        return "error", {"error": "bad vid"}

    if action == "create":
        # Tạo VM config trên node từ config hosting gửi, rồi AUTO-START:
        # download QEMU (AppImage/rootless hoặc build/root) + tải ảnh aria2 + start QEMU.
        # Toàn bộ log → append_vm_log → hiện trong Web UI (SSE) + node terminal.
        c = params.get("config", {})
        if not c:
            return "error", {"error": "no config in create command"}
        c["node"] = "local"
        c["status"] = "downloading"
        save_json(cfg_path(vid), c)
        append_vm_log(vid, f"✅ VM created: {c.get('name','VM')}")
        append_vm_log(vid, f"  preset={c.get('preset_key','?')} cpu={c.get('cpu','?')} ram={c.get('ram_gb','?')}GB")
        append_vm_log(vid, f"  image_path={c.get('image_path','?')}")
        log("NODE", f"  ✅ VM #{vid} config saved — auto-starting download...")
        # Auto-trigger download QEMU + image + start trong background
        _download_and_start_bg(vid, c)
        log_tail = _read_log_tail(vid)
        return "ok", {"running": False, "log_tail": log_tail, "status": "downloading"}

    # Các op khác — cần VM config đã có local
    log("NODE", f"  → vm_op(vid={vid}, op={action})...")
    code, resp = vm_op(vid, action, params)
    status = "ok" if code in (200, 201, 202) else "error"
    result = resp if isinstance(resp, dict) else {"raw": str(resp)}
    # Bổ sung running state + status cho hosting
    result["running"] = is_running(vid)
    if "status" not in result:
        c = load_json(cfg_path(vid))
        result["status"] = c.get("status", "stopped") if c else "stopped"
    # Đọc log tail để gửi về hosting
    result["log_tail"] = _read_log_tail(vid)
    log("NODE", f"  {'✅' if status=='ok' else '❌'} {action} → code={code} status={result.get('status','?')}")
    return status, result

def _read_log_tail(vid, max_bytes=8192):
    """Đọc N bytes cuối của VM log file."""
    try:
        lp = log_path(vid)
        if os.path.exists(lp):
            with open(lp, "r") as f:
                content = f.read()
                return content[-max_bytes:]
    except: pass
    return ""

def _agent_thread(host_url):
    """Main agent loop: register → heartbeat 5s → poll commands → execute → report."""
    host_url = host_url.rstrip("/")
    RETRY_DELAYS = [5, 10, 20, 40, 60]
    retry_idx = 0
    registered = False

    log("NODE", "=" * 60)
    log("NODE", f"Hosting URL : {host_url}")
    log("NODE", f"Node ID     : {NODE_ID}")
    log("NODE", f"Hostname    : {socket.gethostname()}")
    log("NODE", "=" * 60)

    while True:
        payload = _build_node_payload()

        if not registered:
            # ── REGISTER ──
            log("NODE", f"Registering node... → POST {host_url}/api/node/register")
            ok, status, resp = _http_post_json(
                host_url + "/api/node/register", payload, "REGISTER")
            if ok and status == 200:
                log("NODE", "✅ Node Registered Successfully — Heartbeat Started")
                registered = True
                retry_idx = 0
            else:
                delay = RETRY_DELAYS[min(retry_idx, len(RETRY_DELAYS) - 1)]
                log("NODE", f"⏳ Register failed (status={status}). Retry in {delay}s "
                    f"(attempt {retry_idx + 1})...")
                time.sleep(delay)
                retry_idx += 1
                continue
        else:
            # ── HEARTBEAT ──
            ok, status, resp = _http_post_json(
                host_url + "/api/node/heartbeat", payload, "HEARTBEAT")
            if not ok or status != 200:
                log("NODE", f"⚠ Heartbeat failed (status={status}) — sẽ re-register")
                registered = False
                retry_idx = 0
                delay = RETRY_DELAYS[0]
                log("NODE", f"⏳ Retry in {delay}s...")
                time.sleep(delay)
                retry_idx += 1
                continue
            retry_idx = 0
            dbg("NODE", f"Heartbeat OK (vm_count={payload['vm_count']}, "
                f"cpu_free={payload['cpu']['free']})")

            # ── POLL FOR COMMANDS ──
            try:
                ok2, status2, resp2 = _http_post_json(
                    host_url + "/api/node/poll",
                    {"id": NODE_ID}, "POLL")
                if ok2 and status2 == 200:
                    cmds = resp2.get("commands", [])
                    if cmds:
                        log("NODE", f"📬 Poll: {len(cmds)} command(s) received")
                        for cmd in cmds:
                            cmd_id = cmd.get("id", "?")
                            action = cmd.get("action", "?")
                            vid = cmd.get("vid", "?")
                            # Execute command
                            st, result = _execute_command(cmd)
                            # Report result back to hosting
                            ok3, status3, _ = _http_post_json(
                                host_url + "/api/node/result",
                                {"id": NODE_ID, "cmd_id": cmd_id,
                                 "action": action, "vid": vid,
                                 "status": st, "result": result},
                                "RESULT")
                            if ok3 and status3 == 200:
                                dbg("NODE", f"  Result reported: {st}")
                            else:
                                log("NODE", f"  ⚠ Failed to report result (status={status3})")
            except Exception as e:
                dbg("NODE", f"Poll error: {e}")

        # Heartbeat interval
        time.sleep(5)

# ── TUNNEL WATCHDOG ──────────────────────────────────────────────────────────
# localtunnel client KHÔNG auto-reconnect khi server disconnect connection.
# → process vẫn sống nhưng HTTPS trả 000 → tunnel "die".
# Watchdog check health mỗi 60s, restart localtunnel nếu die.

def _tunnel_subdomain():
    """Lấy subdomain từ PUBLIC_URL hoặc env/file."""
    global PUBLIC_URL
    if PUBLIC_URL and ".loca.lt" in PUBLIC_URL:
        return PUBLIC_URL.split("//")[1].split(".")[0]
    sub = os.environ.get("WINBOXES_PANEL_SUBDOMAIN", "")
    if sub: return sub
    try:
        with open(SUBDOMAIN_FILE) as f: return f.read().strip()
    except Exception: return ""

def _kill_localtunnel(sub):
    """Kill mọi process localtunnel cho subdomain này (scan /proc)."""
    for pdir in glob.glob('/proc/[0-9]*'):
        try:
            with open(os.path.join(pdir, 'cmdline'), 'rb') as f:
                cmd = f.read()
            if b'localtunnel' not in cmd: continue
            pid = int(os.path.basename(pdir))
            if pid == os.getpid(): continue
            os.kill(pid, signal.SIGTERM)
        except (OSError, ValueError): continue
    time.sleep(2)
    # SIGKILL stragglers
    for pdir in glob.glob('/proc/[0-9]*'):
        try:
            with open(os.path.join(pdir, 'cmdline'), 'rb') as f:
                cmd = f.read()
            if b'localtunnel' not in cmd: continue
            pid = int(os.path.basename(pdir))
            if pid == os.getpid(): continue
            os.kill(pid, signal.SIGKILL)
        except (OSError, ValueError): continue

def _start_localtunnel(sub, port):
    """Start localtunnel client, return URL or ''."""
    try:
        with open(TUNNEL_LOG, 'w') as f: pass
    except Exception: pass
    proc = subprocess.Popen(
        ['npx', '--yes', 'localtunnel', '--subdomain', sub, '--port', str(port)],
        stdout=open(TUNNEL_LOG, 'w'), stderr=subprocess.STDOUT,
        start_new_session=True)
    try:
        with open(TUNNEL_PID_FILE, 'w') as f: f.write(str(proc.pid))
    except Exception: pass
    # Đợi URL trong log (max 90s)
    want = f"https://{sub}.loca.lt"
    for _ in range(180):
        try:
            with open(TUNNEL_LOG) as f: content = f.read()
        except Exception: content = ""
        import re
        m = re.search(r'https://[a-z0-9.-]+\.loca\.lt', content)
        if m:
            return m.group(0)
        if proc.poll() is not None: break
        time.sleep(0.5)
    return ""

def _check_tunnel_health(url):
    """Return True nếu tunnel còn serve VÀ request tới được backend.
    localtunnel server khi client disconnect có thể trả 502 hoặc error page
    (không phải connection refused) → phải verify response là JSON từ backend."""
    try:
        req = urllib.request.Request(url + "/api/system",
                                      headers={"User-Agent": "WinBoxes-TunnelCheck/1.0"})
        resp = urllib.request.urlopen(req, timeout=10)
        data = resp.read()
        # Verify response từ backend thật (JSON chứa "mode") — không phải lt error page
        return b'"mode"' in data
    except Exception:
        return False

def _tunnel_watchdog():
    """Background thread: check tunnel health mỗi 60s, restart nếu die."""
    global PUBLIC_URL
    sub = _tunnel_subdomain()
    if not sub:
        dbg("TUNNEL", "Watchdog: no subdomain, skipping")
        return
    log("TUNNEL", f"Watchdog started: subdomain={sub}, check every 60s")
    fail_count = 0
    while True:
        time.sleep(60)
        with _tunnel_url_lock:
            url = PUBLIC_URL
        if not url:
            continue
        healthy = _check_tunnel_health(url)
        if healthy:
            if fail_count > 0:
                log("TUNNEL", f"Tunnel recovered: {url}")
            fail_count = 0
            continue
        fail_count += 1
        log("TUNNEL", f"Tunnel health check FAILED ({fail_count}/2): {url}")
        if fail_count < 2:
            continue
        # Tunnel dead → restart localtunnel
        log("TUNNEL", f"Tunnel died — restarting localtunnel (subdomain={sub})...")
        _kill_localtunnel(sub)
        time.sleep(5)  # chờ server release
        # Retry reclaim (max 3)
        new_url = ""
        for attempt in range(1, 4):
            log("TUNNEL", f"  reclaim attempt {attempt}/3...")
            new_url = _start_localtunnel(sub, PORT)
            if new_url == f"https://{sub}.loca.lt":
                break
            if new_url:
                log("TUNNEL", f"  got fallback: {new_url} — retry...")
                _kill_localtunnel(sub)
                time.sleep(10)
            else:
                log("TUNNEL", f"  no URL — retry...")
                time.sleep(10)
        if new_url:
            with _tunnel_url_lock:
                PUBLIC_URL = new_url
            if new_url == f"https://{sub}.loca.lt":
                log("TUNNEL", f"Tunnel restarted OK: {new_url}")
            else:
                log("TUNNEL", f"Tunnel restarted (fallback): {new_url}")
            fail_count = 0
        else:
            log("TUNNEL", "Tunnel restart FAILED — will retry next cycle")
            fail_count = 0  # reset, retry next 60s

# ── MAIN ─────────────────────────────────────────────────────────────────────
def main():
    # Ghi PID file — `WinBoxes-Panel.sh --stop` dùng để dừng panel.
    # QEMU chạy daemonized (process riêng) → KHÔNG bị ảnh hưởng khi panel dừng.
    with open(PANEL_PID_FILE, "w") as f:
        f.write(str(os.getpid()))

    def _cleanup_pid():
        try: os.remove(PANEL_PID_FILE)
        except OSError: pass

    # Tunnel KHÔNG bị dừng khi panel thoát — localtunnel server có release delay
    # dài (60s+), nên kill tunnel rồi restart sẽ nhận fallback URL random.
    # Giữ tunnel sống qua panel restart → URL vĩnh viễn.
    # Dừng tunnel riêng: bash WinBoxes-Panel.sh --kill-tunnel

    def _stop_handler(signum, frame):
        print(f"\n  ⏹ Dừng panel (signal {signum}) — VM + tunnel vẫn chạy\n", flush=True)
        _cleanup_pid()
        raise SystemExit(0)

    signal.signal(signal.SIGTERM, _stop_handler)
    signal.signal(signal.SIGINT, _stop_handler)

    print(f"\n  WinBoxes-Panel  |  mode={MODE}  port={PORT}  v{WINBOX_VER}", flush=True)
    print(f"  data={DATA_DIR}  launcher={LAUNCHER}", flush=True)
    print(f"  winbox={WINBOX or '(none)'}", flush=True)
    if DEBUG:
        print(f"  debug=ON (HTTP request/response logging enabled)", flush=True)
    print(f"  ➜ http://localhost:{PORT}  (web khách hàng — KHÔNG cần login)\n", flush=True)
    if PUBLIC_URL:
        print(f"  ➜ HTTPS tunnel: {PUBLIC_URL}  (localtunnel — custom subdomain, free)\n", flush=True)
    if MODE == "vm":
        vm_mode_agent_loop()
        print("  ➜ Node agent: register + heartbeat 5s tới hosting (cgroup quota)", flush=True)
        print(f"  ➜ Retry: exponential backoff 5→10→20→40→60s nếu hosting offline", flush=True)
        if DEBUG:
            print(f"  ➜ DEBUG: full HTTP request/response logging enabled", flush=True)
    elif MODE == "hosting":
        nodes = load_nodes()
        print(f"  ➜ Hosting mode: {len(nodes)} node(s) trong registry", flush=True)
    # Start tunnel watchdog (hosting mode + tunnel active)
    if MODE == "hosting" and PUBLIC_URL:
        t = threading.Thread(target=_tunnel_watchdog, daemon=True)
        t.start()
        print(f"  ➜ Tunnel watchdog: health check 60s, auto-restart nếu die", flush=True)
    srv = ThreadingHTTPServer(("0.0.0.0", PORT), Handler)
    try:
        srv.serve_forever()
    except SystemExit:
        pass
    finally:
        _cleanup_pid()
        srv.server_close()

if __name__ == "__main__":
    main()
