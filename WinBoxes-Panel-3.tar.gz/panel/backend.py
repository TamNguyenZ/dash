#!/usr/bin/env python3
# ════════════════════════════════════════════════════════════════════════════
#  backend.py — WinBoxes-Panel backend (Python stdlib, rootless-friendly)
#  ----------------------------------------------------------------------------
#  Web cho KHÁCH HÀNG — KHÔNG có admin role, KHÔNG login/token.
#  Khách chỉ thấy VM của mình — KHÔNG thấy node/hostname thông tin.
#
#  REST API (mở): tạo/quản lý VM, console, logs, settings.
#  Scheduler nội bộ: tự chọn node (Best Fit) — khách KHÔNG chọn node.
#  Node↔Hosting: KHÔNG cần key — node chỉ cần biết Hosting URL.
#  KHÔNG chạy QEMU/tải ảnh khi khởi động — chỉ khi API được gọi.
# ════════════════════════════════════════════════════════════════════════════
import os, sys, json, time, hmac, threading, subprocess, shutil, socket, glob, signal
import urllib.request, urllib.error
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs, unquote

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import resource_detect, scheduler

# ── CẤU HÌNH ─────────────────────────────────────────────────────────────────
DATA_DIR   = os.environ.get("WINBOXES_PANEL_DATA", os.path.expanduser("~/.winboxes-panel"))
SCRIPT_DIR = os.environ["WINBOXES_PANEL_SCRIPT_DIR"]
LAUNCHER   = os.environ["WINBOXES_PANEL_LAUNCHER"]
WINBOX     = os.environ.get("WINBOXES_PANEL_WINBOX", "")
MODE       = os.environ.get("WINBOXES_PANEL_MODE", "hosting")
PORT       = int(os.environ.get("WINBOXES_PANEL_PORT", "8090"))
NODE_KEY   = ""  # (deprecated — enrollment key đã bỏ)
WINBOX_VER = "3.2"
NODE_ID    = socket.gethostname() + "-" + str(os.getpid())
# KHÔNG hardcode localhost — node_url chỉ dùng cho hosting→node proxy (nếu cùng mạng).
# Khi node ở máy khác (Colab), hosting không thể reach ngược → VM ops qua push thay vì pull.
NODE_URL   = os.environ.get("WINBOXES_PANEL_NODE_URL", f"http://localhost:{PORT}")
DEBUG      = os.environ.get("WINBOXES_PANEL_DEBUG", "0") in ("1", "true", "yes")

# ── LOGGING ──────────────────────────────────────────────────────────────────
def log(tag, msg):
    """Log có tag, luôn flush để xem realtime. DEBUG=1 → log thêm HTTP detail."""
    ts = time.strftime("%H:%M:%S")
    print(f"  [{ts}] [{tag}] {msg}", flush=True)

def dbg(tag, msg):
    """Debug log — chỉ in khi DEBUG=1."""
    if DEBUG:
        log(tag, f"DEBUG: {msg}")

VM_DIR    = os.path.join(DATA_DIR, "vm")
STATE_DIR = os.path.join(DATA_DIR, "state")
LOG_DIR   = os.path.join(DATA_DIR, "logs")
NODE_DIR  = os.path.join(DATA_DIR, "nodes")
CFG_DIR   = os.path.join(DATA_DIR, "config")
for d in (VM_DIR, STATE_DIR, LOG_DIR, NODE_DIR, CFG_DIR):
    os.makedirs(d, exist_ok=True)

# PID file để `WinBoxes-Panel.sh --stop` dừng panel mà KHÔNG ảnh hưởng VM
PANEL_PID_FILE = os.path.join(DATA_DIR, "panel.pid")

# Hosting event log (disk) — register/heartbeat/offline/removed
HOSTING_LOG = os.path.join(LOG_DIR, "hosting.log")
def hostlog(msg):
    """Ghi hosting event ra disk + console."""
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{ts}] {msg}"
    log("HOST", msg)
    try:
        with open(HOSTING_LOG, "a") as f:
            f.write(line + "\n")
    except OSError:
        pass

PRESETS = [
    {"key":"win2012","name":"Windows Server 2012 R2","url":"https://archive.org/download/tamnguyen-2012r2/2012.img","uefi":False},
    {"key":"win2022","name":"Windows Server 2022","url":"https://archive.org/download/tamnguyen-2022/2022.img","uefi":False},
    {"key":"win11","name":"Windows 11 LTSB","url":"https://archive.org/download/win_20260203/win.img","uefi":True},
    {"key":"win10ltsb","name":"Windows 10 LTSB 2015","url":"https://archive.org/download/win_20260208/win.img","uefi":False},
    {"key":"win10ltsc","name":"Windows 10 LTSC 2023","url":"https://archive.org/download/win_20260215/win.img","uefi":False},
    {"key":"win10ltsb2022","name":"Windows 10 LTSB 2022","url":"https://archive.org/download/win_20260717/win.img","uefi":False},
]
PRESET_BY_KEY = {p["key"]: p for p in PRESETS}
DEFAULTS = {"theme":"dark","language":"vi","auto_refresh":3,"timeout":30,
            "default_ram":2,"default_cpu":2,"default_disk":40}

# ── HELPERS ──────────────────────────────────────────────────────────────────
def cfg_path(vid): return os.path.join(CFG_DIR, f"vm_{vid}.json")
def state_path(vid): return os.path.join(STATE_DIR, f"vm_{vid}.json")
def log_path(vid): return os.path.join(LOG_DIR, f"vm_{vid}.log")
def load_json(path, default=None):
    try:
        with open(path) as f: return json.load(f)
    except Exception: return default
def save_json(path, obj):
    with open(path, "w") as f: json.dump(obj, f, indent=2)
def list_vm_configs():
    out = []
    for p in sorted(glob.glob(os.path.join(CFG_DIR, "vm_*.json"))):
        c = load_json(p)
        if c: out.append(c)
    return out
def next_vm_id():
    ids = [c["id"] for c in list_vm_configs()]
    return (max(ids) + 1) if ids else 1
def runtime_state(vid): return load_json(state_path(vid), {})
def is_running(vid):
    pidf = os.path.join(VM_DIR, f"vm_{vid}.pid")
    try:
        with open(pidf) as f: pid = int(f.read().strip())
        os.kill(pid, 0); return True
    except Exception: return False

def strip_node_info(vm):
    """Ẩn thông tin node/hostname khỏi response cho khách hàng. Khách chỉ thấy VM."""
    v = dict(vm)
    for k in ("node","node_url","node_vm_id","hostname","environment","is_container","is_rootless","os","arch"):
        v.pop(k, None)
    return v

# ── SYSTEM INFO (không tiết lộ node internals cho khách) ──────────────────────
def system_info():
    """Thông tin hệ thống cho dashboard khách hàng — KHÔNG lộ node/hostname."""
    return {
        "mode": MODE, "has_kvm": os.path.exists("/dev/kvm"),
        "winbox_available": bool(WINBOX), "python": sys.version.split()[0],
        "data_dir": DATA_DIR, "version": WINBOX_VER,
    }
def metrics():
    snap = resource_detect.snapshot(VM_DIR, WINBOX_VER)
    vms = list_vm_configs()
    return {"cpu_percent": snap["cpu"]["usage_percent"],
            "ram": {"total_mb": snap["ram"]["total"]//1048576, "used_mb": snap["ram"]["used"]//1048576,
                    "percent": snap["ram"]["usage_percent"]},
            "disk": {"total_gb": round(snap["disk"]["total"]/1e9,1), "used_gb": round(snap["disk"]["used"]/1e9,1),
                     "percent": snap["disk"]["usage_percent"]},
            "net": {"rx_mb": round(snap["net"]["rx_bytes"]/1e6,1), "tx_mb": round(snap["net"]["tx_bytes"]/1e6,1)},
            "uptime": snap["uptime"], "vms_total": len(vms),
            "vms_running": sum(1 for c in vms if is_running(c["id"])),
            "load_average": snap["load_average"]}

def vm_monitor(vid):
    st = runtime_state(vid); running = is_running(vid)
    started = st.get("started_at",0)
    up = int(time.time()-started) if running and started else 0
    qmp_status = None
    if running:
        try:
            out = subprocess.run([LAUNCHER,"qmp",str(vid),'{"execute":"query-status"}'],
                                 capture_output=True,text=True,timeout=3).stdout
            for line in out.splitlines():
                if "status" in line: qmp_status = json.loads(line); break
        except: pass
    # KHÔNG trả "node" — khách không thấy
    return {"running":running,"uptime":up,"rdp_port":st.get("rdp_port"),
            "vnc_raw_port":st.get("vnc_raw_port"),"ws_port":st.get("ws_port"),
            "qmp_status":qmp_status,"pid":st.get("pid")}

# ── NODE REGISTRY (nội bộ — KHÔNG expose cho khách) ──────────────────────────
def nodes_path(): return os.path.join(NODE_DIR, "nodes.json")
def load_nodes_dict(): return load_json(nodes_path(), {})
def load_nodes():
    d = load_nodes_dict(); now = time.time()
    out = []
    for nid, n in d.items():
        n = dict(n); n["online"] = (now - n.get("last_seen",0)) < scheduler.OFFLINE_THRESHOLD
        n["id"] = nid; out.append(n)
    return out
def save_node(info):
    d = load_nodes_dict()
    d[info["id"]] = {**d.get(info["id"],{}), **info, "last_seen": time.time()}
    save_json(nodes_path(), d)
def get_node(nid): return load_nodes_dict().get(nid)

# ── COMMAND QUEUE (Hosting → Node, pull model) ───────────────────────────────
# Node ở Colab (behind NAT) → hosting KHÔNG thể push lệnh xuống.
# Thay vàoo: hosting queue lệnh vào disk, node poll lấy + execute + report.
CMD_DIR = os.path.join(DATA_DIR, "commands")
os.makedirs(CMD_DIR, exist_ok=True)

def cmd_dir(node_id): return os.path.join(CMD_DIR, node_id)
def queue_command(node_id, action, vid, params=None):
    """Queue một lệnh cho node. Node sẽ poll và lấy lệnh này."""
    d = cmd_dir(node_id); os.makedirs(d, exist_ok=True)
    cmd_id = f"cmd_{int(time.time()*1000)}"
    cmd = {"id": cmd_id, "node": node_id, "action": action,
           "vid": vid, "params": params or {}, "queued_at": int(time.time())}
    save_json(os.path.join(d, cmd_id + ".json"), cmd)
    return cmd
def get_pending_commands(node_id):
    d = cmd_dir(node_id)
    if not os.path.isdir(d): return []
    out = []
    for f in sorted(glob.glob(os.path.join(d, "*.json"))):
        cmd = load_json(f)
        if cmd: out.append(cmd)
    return out
def ack_command(node_id, cmd_id):
    try: os.remove(os.path.join(cmd_dir(node_id), cmd_id + ".json"))
    except OSError: pass

# ── REMOTE VM STATES (node báo cáo runtime state qua heartbeat) ──────────────
REMOTE_VM_STATES = {}  # {vid: {"running":..,"uptime":..,"rdp_port":..,...}}
def update_remote_states(node_id, states):
    """Merge VM states từ node heartbeat vào global remote states."""
    if not states: return
    for vid_str, st in states.items():
        try: vid = int(vid_str)
        except: continue
        REMOTE_VM_STATES[vid] = {**st, "node_id": node_id, "updated": time.time()}

# ── NODE PROXY (Hosting → Node) ──────────────────────────────────────────────
def node_proxy_http(node_url, path, method="POST", body=None, timeout=30):
    url = node_url.rstrip("/") + path
    headers = {"Content-Type": "application/json"}
    data = json.dumps(body).encode() if body is not None else None
    try:
        req = urllib.request.Request(url, data=data, headers=headers, method=method)
        with urllib.request.urlopen(req, timeout=timeout) as r:
            txt = r.read().decode()
            return r.status, (json.loads(txt) if txt else {})
    except urllib.error.HTTPError as e:
        txt = e.read().decode()
        try: return e.code, json.loads(txt)
        except: return e.code, {"error": txt}
    except Exception as e:
        return 0, {"error": f"node unreachable: {e}"}

# ── VM OPS (local) ───────────────────────────────────────────────────────────
def run_launcher(args, timeout=10):
    try:
        r = subprocess.run(["bash", LAUNCHER, *args], capture_output=True, text=True,
                            timeout=timeout, env=dict(os.environ))
        return r.returncode, r.stdout, r.stderr
    except subprocess.TimeoutExpired:
        return 124, "", "timeout"

def vm_start_local(vid):
    c = load_json(cfg_path(vid))
    if not c: return 404, {"error":"not found"}
    args = ["start", str(vid), c["image_path"], str(c["ram_gb"]), str(c["cpu"]),
            str(c.get("rdp_port",3388+vid)), str(c.get("vnc_display",vid-1)),
            str(c.get("ws_port",6000+vid)), c.get("machine","q35"),
            "1" if c.get("uefi") else "0"]
    args += [f"{f['host']}:{f['guest']}" for f in c.get("forwards",[])]
    rc, out, err = run_launcher(args, timeout=30)
    return (200 if rc==0 else 500), {"rc":rc,"stdout":out[-500:],"stderr":err[-500:]}

def vm_stop_local(vid):
    rc, out, err = run_launcher(["stop", str(vid)], timeout=40)
    return (200 if rc==0 else 500), {"rc":rc,"stdout":out,"stderr":err}

def vm_clone_local(vid):
    c = load_json(cfg_path(vid))
    if not c: return 404, {"error":"not found"}
    if is_running(vid): return 409, {"error":"stop vm before clone"}
    new_id = next_vm_id()
    new_img = os.path.join(VM_DIR, f"vm_{new_id}.img")
    try: shutil.copyfile(c["image_path"], new_img)
    except Exception as e: return 500, {"error":str(e)}
    nc = dict(c); nc["id"]=new_id; nc["name"]=c["name"]+" (clone)"; nc["image_path"]=new_img
    nc["rdp_port"]=3388+new_id; nc["vnc_display"]=new_id-1; nc["ws_port"]=6000+new_id
    nc["created_at"]=int(time.time()); nc.pop("node", None)
    save_json(cfg_path(new_id), nc)
    return 200, strip_node_info(nc)

def vm_delete_local(vid):
    if is_running(vid): vm_stop_local(vid)
    for p in (cfg_path(vid), state_path(vid)):
        try: os.remove(p)
        except: pass
    return 200, {"ok":True}

def vm_download_local(vid):
    c = load_json(cfg_path(vid))
    if not c: return 404, {"error":"not found"}
    if not WINBOX: return 503, {"error":"winboxes.sh not available"}
    key = c.get("preset_key")
    if not key: return 400, {"error":"not a preset vm"}
    job_dir = os.path.join(DATA_DIR, "jobs"); os.makedirs(job_dir, exist_ok=True)
    logf = os.path.join(job_dir, f"download_{vid}_{int(time.time())}.log")
    target = os.path.dirname(c["image_path"])
    def _bg():
        try:
            with open(logf,"w") as f:
                p = subprocess.Popen(["bash", WINBOX, "--auto", f"--{key}", "--no-vnc"],
                                     stdout=f, stderr=subprocess.STDOUT, cwd=target, env=dict(os.environ))
                p.wait()
            if os.path.exists(os.path.join(target, "win.img")):
                shutil.move(os.path.join(target,"win.img"), c["image_path"])
        except Exception as e:
            with open(logf,"a") as f: f.write(f"\nERROR: {e}\n")
    threading.Thread(target=_bg, daemon=True).start()
    return 202, {"job_log": logf, "status":"started"}

# ── SCHEDULER-INTEGRATED VM CREATE ───────────────────────────────────────────
def vm_create_scheduled(b):
    vid = next_vm_id()
    key = b.get("preset_key","")
    preset = PRESET_BY_KEY.get(key)
    uefi = preset["uefi"] if preset else b.get("uefi",False)
    img = b.get("image_path") or os.path.join(VM_DIR, f"vm_{vid}.img")
    req_cpu = int(b.get("cpu", DEFAULTS["default_cpu"]))
    req_ram_gb = int(b.get("ram_gb", DEFAULTS["default_ram"]))
    req_disk_gb = int(b.get("disk_gb", DEFAULTS["default_disk"]))
    c = {
        "id": vid, "name": b.get("name", f"VM-{vid}"),
        "image_path": img, "preset_key": key, "uefi": uefi,
        "ram_gb": req_ram_gb, "cpu": req_cpu, "disk_gb": req_disk_gb,
        "machine": b.get("machine","q35"), "forwards": b.get("forwards",[]),
        "rdp_port": 3388+vid, "vnc_display": vid-1, "ws_port": 6000+vid,
        "created_at": int(time.time()), "node": None,
    }
    if MODE == "hosting":
        # Hosting mode: BẮT BUỘC route VM tới node đã đăng ký.
        online_nodes = [n for n in load_nodes() if n.get("online") and n.get("cpu")]
        if not online_nodes:
            return 503, {"error":"no_node",
                         "message":"Chưa có Node nào online. Hãy chạy WinBoxes ở VM Mode "
                                   "trên máy khác và đăng ký lên Hosting này.",
                         "scheduled":False}
        try:
            chosen = scheduler.schedule(online_nodes, req_cpu,
                                        req_ram_gb*1024**3, req_disk_gb*1024**3)
        except scheduler.SchedulerError as e:
            return 503, {"error":"no_node","message":str(e),"scheduled":False}
        c["node"] = chosen["id"]
        # Lưu config trên hosting (hiển thị dashboard) + queue lệnh "create" cho node
        save_json(cfg_path(vid), c)
        queue_command(chosen["id"], "create", vid, {"config": c})
        hostlog(f"📤 VM #{vid} '{c['name']}' queued for node '{chosen['id']}' (create)")
    else:
        # VM mode: tạo VM nội bộ trên node này
        c["node"] = "local"
        save_json(cfg_path(vid), c)
    return 201, strip_node_info(c)

# ── VM OPS ROUTER ─────────────────────────────────────────────────────────────
def vm_op(vid, op, extra=None):
    c = load_json(cfg_path(vid))
    if not c: return 404, {"error":"not found"}
    node = c.get("node", "local")
    if node in ("local", None) or node == NODE_ID:
        # ── Local execution ──
        if op=="start": return vm_start_local(vid)
        if op=="stop": return vm_stop_local(vid)
        if op=="restart": vm_stop_local(vid); time.sleep(2); return vm_start_local(vid)
        if op=="download": return vm_download_local(vid)
        if op=="clone": return vm_clone_local(vid)
        if op=="delete": return vm_delete_local(vid)
        if op=="rename":
            c["name"]=extra.get("name",c["name"]); save_json(cfg_path(vid),c); return 200, strip_node_info(c)
        if op=="resize":
            rc,o,e=run_launcher(["resize",str(vid),c["image_path"],extra.get("size","+5G")],timeout=120)
            return (200 if rc==0 else 500),{"rc":rc,"output":o,"error":e}
        if op=="snapshot":
            rc,o,e=run_launcher(["snapshot",str(vid),extra.get("action","list"),
                                 extra.get("name",""),c["image_path"]],timeout=15)
            return (200 if rc==0 else 500),{"rc":rc,"output":o,"error":e}
        return 404, {"error":"unknown op"}
    else:
        # ── Remote node: queue command (pull model) ──
        # Node ở Colab (behind NAT) → hosting KHÔNG thể push HTTP trực tiếp.
        # Queue lệnh vào disk, node sẽ poll lấy + execute + report.
        n = get_node(node)
        if not n: return 502, {"error":"node unavailable"}
        queue_command(node, op, vid, extra or {})
        hostlog(f"📤 VM #{vid} op='{op}' queued for node '{node}'")
        return 202, {"ok":True, "status":"queued", "node":node, "op":op, "vid":vid}

# ════════════════════════════════════════════════════════════════════════════
#  HTTP HANDLER — MỞ cho khách hàng, node_auth nội bộ cho register/heartbeat
# ════════════════════════════════════════════════════════════════════════════
class Handler(BaseHTTPRequestHandler):
    server_version = "WinBoxes-Panel/1.0"
    def log_message(self, *a): pass

    def _send(self, code, obj=None, ctype="application/json", body=None):
        if body is None:
            body = json.dumps(obj).encode() if obj is not None else b""
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control","no-store")
        self.send_header("Access-Control-Allow-Origin","*")
        self.end_headers()
        if self.command != "HEAD":
            try: self.wfile.write(body)
            except: pass

    def _body(self):
        ln = int(self.headers.get("Content-Length",0))
        if not ln: return {}
        try: return json.loads(self.rfile.read(ln))
        except: return {}

    def do_OPTIONS(self): self._send(200, body=b"")

    # ── GET (khách hàng — mở) ──────────────────────────────────────────────
    def do_GET(self):
        u = urlparse(self.path); p = u.path
        if p == "/" or p == "/index.html": return self._serve_static("static/index.html","text/html")
        if p.startswith("/static/"): return self._serve_static(unquote(p[1:]))
        if p.startswith("/console/"): return self._serve_static("static/console.html","text/html")
        if p == "/api/presets": return self._send(200, PRESETS)
        if p == "/api/system": return self._send(200, {**system_info(), "metrics": metrics()})
        if p == "/api/settings": return self._send(200, load_json(os.path.join(DATA_DIR,"settings.json"), DEFAULTS))
        if p == "/api/vm":
            vms = []
            for c in list_vm_configs():
                v = {**c, "runtime": runtime_state(c["id"])}
                node = c.get("node", "local")
                if node in ("local", None) or node == NODE_ID:
                    v["running"] = is_running(c["id"])
                else:
                    # Remote VM — lấy running state từ REMOTE_VM_STATES (node báo qua heartbeat)
                    rst = REMOTE_VM_STATES.get(c["id"], {})
                    v["running"] = rst.get("running", False)
                    v["runtime"] = rst
                vms.append(strip_node_info(v))
            return self._send(200, vms)
        if p == "/api/scheduler/can-fit":
            # Khách xem có thể tạo VM cấu hình X không — KHÔNG lộ node nào
            q = parse_qs(u.query)
            try: cpu=int(q.get("cpu",["2"])[0]); ram=int(q.get("ram",["2"])[0]); disk=int(q.get("disk",["40"])[0])
            except: return self._send(400,{"error":"bad params"})
            nodes = [n for n in load_nodes() if n.get("online") and n.get("cpu")]
            try:
                scheduler.schedule(nodes, cpu, ram*1024**3, disk*1024**3)
                return self._send(200, {"ok":True,"message":"Sẵn sàng cấp phát"})
            except scheduler.SchedulerError as e:
                return self._send(200, {"ok":False,"message":str(e)})
        if p == "/api/nodes":
            # Hosting dashboard — list tất cả node với status online/offline
            nodes = load_nodes()
            now = time.time()
            out = []
            for n in nodes:
                online = (now - n.get("last_seen", 0)) < scheduler.OFFLINE_THRESHOLD
                cpu = n.get("cpu", {})
                ram = n.get("ram", {})
                disk = n.get("disk", {})
                out.append({
                    "id": n.get("id", "?"),
                    "hostname": n.get("hostname", "?"),
                    "environment": n.get("environment", "?"),
                    "online": online,
                    "last_seen": n.get("last_seen", 0),
                    "last_seen_ago": int(now - n.get("last_seen", 0)),
                    "cpu": {
                        "total": cpu.get("total", 0),
                        "free": cpu.get("free", 0),
                        "usage_percent": cpu.get("usage_percent", 0),
                        "source": cpu.get("source", "?"),
                    },
                    "ram": {
                        "total_mb": ram.get("total", 0) // 1048576,
                        "free_mb": ram.get("free", 0) // 1048576,
                        "usage_percent": ram.get("usage_percent", 0),
                        "source": ram.get("source", "?"),
                    },
                    "disk": {
                        "total_gb": round(disk.get("total", 0) / 1e9, 1),
                        "free_gb": round(disk.get("free", 0) / 1e9, 1),
                        "usage_percent": disk.get("usage_percent", 0),
                        "source": disk.get("source", "?"),
                    },
                    "vm_count": n.get("vm_count", 0),
                    "load_average": n.get("load_average", [0, 0, 0]),
                    "uptime": n.get("uptime", 0),
                    "os": n.get("os", {}),
                    "arch": n.get("arch", "?"),
                    "is_container": n.get("is_container", False),
                    "is_rootless": n.get("is_rootless", False),
                    "winbox_version": n.get("winbox_version", "?"),
                })
            return self._send(200, out)
        # /api/vm/<id>/...
        parts = [x for x in p.split("/") if x]
        if len(parts)>=3 and parts[0]=="api" and parts[1]=="vm":
            try: vid = int(parts[2])
            except: return self._send(400, {"error":"bad id"})
            if len(parts)==3:
                c = load_json(cfg_path(vid))
                if not c: return self._send(404, {"error":"not found"})
                node = c.get("node", "local")
                if node in ("local", None) or node == NODE_ID:
                    c["running"]=is_running(vid); c["runtime"]=runtime_state(vid)
                else:
                    rst = REMOTE_VM_STATES.get(vid, {})
                    c["running"]=rst.get("running", False); c["runtime"]=rst
                return self._send(200, strip_node_info(c))
            sub = parts[3]
            if sub=="status": return self._send(200, runtime_state(vid))
            if sub=="monitor": return self._send(200, vm_monitor(vid))
            if sub=="console":
                st=runtime_state(vid)
                return self._send(200, {"ws_port":st.get("ws_port",6000+vid),
                                        "vnc_raw_port":st.get("vnc_raw_port",5900+vid-1),
                                        "running":is_running(vid)})
            if sub=="snapshots":
                c=load_json(cfg_path(vid))
                rc,o,e=run_launcher(["snapshot",str(vid),"list","",c["image_path"] if c else ""],timeout=5)
                return self._send(200, {"output":o})
            if sub=="logs": return self._sse_logs(vid)
            return self._send(404, {"error":"unknown sub"})
        return self._send(404, {"error":"not found"})

    # ── POST ──────────────────────────────────────────────────────────────
    def do_POST(self):
        u = urlparse(self.path); p = u.path; b = self._body()
        # ── Node↔Hosting (register/heartbeat — KHÔNG cần key) ──────────────
        if p == "/api/node/register":
            nid = b.get("id", "?")
            host = b.get("hostname", "?")
            env = b.get("environment", "?")
            cpu = b.get("cpu", {})
            ram = b.get("ram", {})
            disk = b.get("disk", {})
            dbg("HOST", f"Incoming registration: id={nid} host={host} env={env}")
            # Valid — log chi tiết
            hostlog(f"📥 Incoming Registration:")
            hostlog(f"   Node ID   : {nid}")
            hostlog(f"   Hostname  : {host}")
            hostlog(f"   Environment: {env}")
            hostlog(f"   CPU       : {cpu.get('total',0)} core ({cpu.get('source','?')})")
            hostlog(f"   RAM       : {ram.get('total',0)//1048576} MB ({ram.get('source','?')})")
            hostlog(f"   Disk      : {disk.get('total',0)//1073741824} GB ({disk.get('source','?')})")
            save_node(b)
            hostlog(f"✅ Registration SUCCESS — Node '{nid}' added to registry + scheduler")
            return self._send(200, {"ok":True, "registered":nid, "added_to_scheduler":True})

        if p == "/api/node/heartbeat":
            nid = b.get("id", "?")
            d = load_nodes_dict()
            if nid not in d:
                # Node chưa register → tự register qua heartbeat (recovery)
                hostlog(f"🔄 Heartbeat from unregistered node '{nid}' — auto-registering")
                save_node(b)
                hostlog(f"✅ Node '{nid}' recovered (auto-registered via heartbeat)")
                # Nhận VM states từ node
                update_remote_states(nid, b.get("vm_states"))
                return self._send(200, {"ok":True, "recovered":True})
            d[nid] = {**d[nid], **b, "last_seen": time.time(), "online": True}
            save_json(nodes_path(), d)
            # Nhận VM states từ node
            update_remote_states(nid, b.get("vm_states"))
            dbg("HOST", f"Heartbeat OK: {nid} "
                f"cpu={b.get('cpu',{}).get('free',0)} ram={b.get('ram',{}).get('free',0)//1048576}MB "
                f"vm={b.get('vm_count',0)}")
            return self._send(200, {"ok":True})

        if p == "/api/node/poll":
            # Node poll lấy pending commands
            nid = b.get("id", "?")
            cmds = get_pending_commands(nid)
            if cmds:
                dbg("HOST", f"Node '{nid}' polled: {len(cmds)} command(s) pending")
            return self._send(200, {"commands": cmds})

        if p == "/api/node/result":
            # Node báo kết quả thực thi command
            nid = b.get("id", "?")
            cmd_id = b.get("cmd_id", "?")
            action = b.get("action", "?")
            vid = b.get("vid", "?")
            status = b.get("status", "unknown")
            result = b.get("result", {})
            ack_command(nid, cmd_id)
            hostlog(f"📥 Result from '{nid}': VM #{vid} {action} → {status}")
            # Cập nhật remote VM state nếu node báo running status
            if "running" in result:
                REMOTE_VM_STATES[vid] = {**result, "node_id": nid, "updated": time.time()}
            return self._send(200, {"ok":True})

        if p == "/api/vm/internal/create":
            vid = next_vm_id(); c = dict(b); c["id"]=vid; c["node"]="local"
            save_json(cfg_path(vid), c); return self._send(201, {"id":vid,"ok":True})
        # Khách hàng (mở — không auth)
        if p == "/api/vm": return self._send(*vm_create_scheduled(b))
        if p == "/api/settings":
            save_json(os.path.join(DATA_DIR,"settings.json"), {**DEFAULTS, **b}); return self._send(200, {"ok":True})
        parts = [x for x in p.split("/") if x]
        if len(parts)>=4 and parts[0]=="api" and parts[1]=="vm":
            try: vid=int(parts[2])
            except: return self._send(400, {"error":"bad id"})
            sub = parts[3]
            op_map = {"start":"start","stop":"stop","restart":"restart","download":"download",
                      "clone":"clone","rename":"rename","resize":"resize","snapshot":"snapshot"}
            if sub in op_map: return self._send(*vm_op(vid, op_map[sub], b))
            return self._send(404,{"error":"unknown sub"})
        return self._send(404, {"error":"not found"})

    def do_DELETE(self):
        parts=[x for x in urlparse(self.path).path.split("/") if x]
        if len(parts)==3 and parts[0]=="api" and parts[1]=="vm":
            try: vid=int(parts[2])
            except: return self._send(400,{"error":"bad id"})
            return self._send(*vm_op(vid,"delete"))
        return self._send(404,{"error":"not found"})

    # ── SSE logs ─────────────────────────────────────────────────────────────
    def _sse_logs(self, vid):
        self.send_response(200)
        self.send_header("Content-Type","text/event-stream")
        self.send_header("Cache-Control","no-cache")
        self.send_header("Connection","keep-alive")
        self.end_headers()
        path = log_path(vid); pos = 0
        try:
            if os.path.exists(path):
                with open(path,"rb") as f: data=f.read()
                for ln in data.splitlines()[-50:]:
                    self.wfile.write(f"data: {ln.decode(errors='replace')}\n\n".encode()); self.wfile.flush()
                pos=len(data)
        except: pass
        end = time.time()+60
        while time.time()<end:
            try:
                if os.path.exists(path):
                    with open(path,"rb") as f:
                        f.seek(pos); chunk=f.read()
                    if chunk:
                        for ln in chunk.splitlines():
                            self.wfile.write(f"data: {ln.decode(errors='replace')}\n\n".encode()); self.wfile.flush()
                        pos+=len(chunk)
                    else:
                        self.wfile.write(b": ping\n\n"); self.wfile.flush()
                else:
                    self.wfile.write(b": waiting\n\n"); self.wfile.flush()
            except (BrokenPipeError, ConnectionResetError): break
            time.sleep(0.8)

    def _serve_static(self, rel, ctype=None):
        path = os.path.join(SCRIPT_DIR, "panel", rel.replace("/", os.sep))
        if not os.path.isfile(path): return self._send(404, {"error":"file not found","path":rel})
        if ctype is None:
            ext = os.path.splitext(path)[1].lower()
            ctype = {".html":"text/html",".js":"application/javascript",
                     ".css":"text/css",".png":"image/png",".svg":"image/svg+xml"}.get(ext,"application/octet-stream")
        with open(path,"rb") as f: body=f.read()
        self._send(200, body=body, ctype=ctype)

# ════════════════════════════════════════════════════════════════════════════
#  VM MODE: Node Agent — Register + Heartbeat với retry/backoff
#  ----------------------------------------------------------------------------
#  Kiến trúc: Node (Colab/VPS) → push → Hosting (Neurodesk) qua URL công khai.
#  KHÔNG dùng localhost. Node tự đăng ký, gửi heartbeat 5s, retry exponential.
#  Hosting restart / mạng rớt → node tự re-register, KHÔNG cần restart.
# ════════════════════════════════════════════════════════════════════════════

def _build_node_payload():
    """Build full node payload từ resource_detect — gửi cho register + heartbeat."""
    snap = resource_detect.snapshot(VM_DIR, WINBOX_VER)
    # Thu thập VM states để báo cáo cho hosting (cho dashboard)
    vm_states = {}
    for c in list_vm_configs():
        vid = c["id"]
        rst = runtime_state(vid)
        vm_states[str(vid)] = {
            "running": is_running(vid),
            "uptime": int(time.time() - rst.get("started_at", 0)) if is_running(vid) and rst.get("started_at") else 0,
            "rdp_port": rst.get("rdp_port", c.get("rdp_port")),
            "ws_port": rst.get("ws_port", c.get("ws_port")),
            "pid": rst.get("pid"),
        }
    return {
        "id": NODE_ID,
        "hostname": socket.gethostname(),
        "url": NODE_URL,
        "environment": snap["environment"],
        "is_container": snap["is_container"], "is_rootless": snap["is_rootless"],
        "cpu": snap["cpu"], "ram": snap["ram"], "disk": snap["disk"],
        "load_average": snap["load_average"], "net": snap["net"],
        "vm_count": snap["vm_count"], "uptime": snap["uptime"],
        "os": snap["os"], "arch": snap["arch"],
        "winbox_version": snap["winbox_version"],
        "online": True, "timestamp": int(time.time()),
        "vm_states": vm_states,
    }

def _http_post_json(url, body, tag="HTTP"):
    """
    POST JSON tới url. Trả (ok, status, response_body).
    Log đầy đủ lỗi: HTTP status, timeout, connection refused, DNS, TLS.
    """
    data = json.dumps(body).encode()
    headers = {"Content-Type": "application/json"}
    if DEBUG:
        dbg(tag, f"POST {url}")
        dbg(tag, f"Headers: {headers}")
        dbg(tag, f"Body keys: {list(body.keys())}")
        dbg(tag, f"Body: {json.dumps(body)[:500]}")
    try:
        req = urllib.request.Request(url, data=data, headers=headers, method="POST")
        with urllib.request.urlopen(req, timeout=15) as r:
            txt = r.read().decode()
            resp = json.loads(txt) if txt else {}
            if DEBUG:
                dbg(tag, f"Response {r.status}: {json.dumps(resp)[:300]}")
            return True, r.status, resp
    except urllib.error.HTTPError as e:
        txt = ""
        try: txt = e.read().decode()
        except: pass
        code_map = {401:"401 Unauthorized", 403:"403 Forbidden", 404:"404 Not Found",
                    500:"500 Internal Server Error"}
        reason = code_map.get(e.code, f"HTTP {e.code}")
        log(tag, f"❌ {reason} — {txt[:200]}")
        return False, e.code, {"error": txt}
    except urllib.error.URLError as e:
        cause = e.reason if hasattr(e, "reason") else str(e)
        if "Name or service not known" in str(cause) or "nodename" in str(cause):
            log(tag, f"❌ DNS Error — không phân giải được hostname: {url}")
        elif "Connection refused" in str(cause):
            log(tag, f"❌ Connection Refused — hosting không chạy hoặc sai port: {url}")
        elif "timed out" in str(cause).lower():
            log(tag, f"❌ Timeout — hosting không phản hồi trong 15s: {url}")
        elif "certificate" in str(cause).lower() or "ssl" in str(cause).lower():
            log(tag, f"❌ TLS/SSL Error — chứng chỉ không hợp lệ: {cause}")
        else:
            log(tag, f"❌ Connection Error: {cause}")
        return False, 0, {"error": str(cause)}
    except Exception as e:
        log(tag, f"❌ Unexpected error: {type(e).__name__}: {e}")
        return False, 0, {"error": str(e)}

def vm_mode_agent_loop():
    """
    Node Agent — chạy nền khi MODE=vm.
    1. Đọc hosting URL từ file (KHÔNG cần enrollment key)
    2. Register (POST /api/node/register) với full payload
    3. Heartbeat 5s (POST /api/node/heartbeat)
    4. Retry exponential: 5, 10, 20, 40, 60s — không thoát
    5. Hosting online lại → tự re-register, không cần restart
    """
    hf = os.environ.get("WINBOXES_PANEL_HOSTING_FILE")
    if not hf or not os.path.exists(hf):
        log("NODE", "Không có hosting file — chạy VM mode độc lập (standalone).")
        return
    try:
        with open(hf) as f:
            host_url = f.readline().strip()
    except Exception as e:
        log("NODE", f"❌ Không đọc được hosting file ({hf}): {e}")
        return
    if not host_url:
        log("NODE", f"❌ Hosting file thiếu URL (file={hf})")
        return

    threading.Thread(target=_agent_thread, args=(host_url,), daemon=True).start()

def _execute_command(cmd):
    """Execute một command từ hosting queue. Trả (status, result)."""
    action = cmd.get("action", "")
    vid = cmd.get("vid", 0)
    params = cmd.get("params", {})
    log("NODE", f"  ▶ Executing: {action} VM #{vid}")

    try:
        vid = int(vid)
    except (ValueError, TypeError):
        return "error", {"error": "bad vid"}

    if action == "create":
        # Tạo VM config trên node từ config hosting gửi
        c = params.get("config", {})
        if not c:
            return "error", {"error": "no config in create command"}
        c["node"] = "local"
        save_json(cfg_path(vid), c)
        log("NODE", f"  ✅ VM #{vid} config saved locally")
        return "ok", {"running": is_running(vid)}

    # Các op khác — cần VM config đã có local
    code, resp = vm_op(vid, action, params)
    status = "ok" if code in (200, 201, 202) else "error"
    result = resp if isinstance(resp, dict) else {"raw": str(resp)}
    # Bổ sung running state cho hosting
    result["running"] = is_running(vid)
    log("NODE", f"  {'✅' if status=='ok' else '❌'} {action} → {code}")
    return status, result

def _agent_thread(host_url):
    """Main agent loop: register → heartbeat 5s → poll commands → execute → report."""
    host_url = host_url.rstrip("/")
    RETRY_DELAYS = [5, 10, 20, 40, 60]
    retry_idx = 0
    registered = False

    log("NODE", "=" * 60)
    log("NODE", f"Hosting URL : {host_url}")
    log("NODE", f"Node ID     : {NODE_ID}")
    log("NODE", f"Hostname    : {socket.gethostname()}")
    log("NODE", "=" * 60)

    while True:
        payload = _build_node_payload()

        if not registered:
            # ── REGISTER ──
            log("NODE", f"Registering node... → POST {host_url}/api/node/register")
            ok, status, resp = _http_post_json(
                host_url + "/api/node/register", payload, "REGISTER")
            if ok and status == 200:
                log("NODE", "✅ Node Registered Successfully — Heartbeat Started")
                registered = True
                retry_idx = 0
            else:
                delay = RETRY_DELAYS[min(retry_idx, len(RETRY_DELAYS) - 1)]
                log("NODE", f"⏳ Register failed (status={status}). Retry in {delay}s "
                    f"(attempt {retry_idx + 1})...")
                time.sleep(delay)
                retry_idx += 1
                continue
        else:
            # ── HEARTBEAT ──
            ok, status, resp = _http_post_json(
                host_url + "/api/node/heartbeat", payload, "HEARTBEAT")
            if not ok or status != 200:
                log("NODE", f"⚠ Heartbeat failed (status={status}) — sẽ re-register")
                registered = False
                retry_idx = 0
                delay = RETRY_DELAYS[0]
                log("NODE", f"⏳ Retry in {delay}s...")
                time.sleep(delay)
                retry_idx += 1
                continue
            retry_idx = 0
            dbg("NODE", f"Heartbeat OK (vm_count={payload['vm_count']}, "
                f"cpu_free={payload['cpu']['free']})")

            # ── POLL FOR COMMANDS ──
            try:
                ok2, status2, resp2 = _http_post_json(
                    host_url + "/api/node/poll",
                    {"id": NODE_ID}, "POLL")
                if ok2 and status2 == 200:
                    cmds = resp2.get("commands", [])
                    if cmds:
                        log("NODE", f"📬 Poll: {len(cmds)} command(s) received")
                        for cmd in cmds:
                            cmd_id = cmd.get("id", "?")
                            action = cmd.get("action", "?")
                            vid = cmd.get("vid", "?")
                            # Execute command
                            st, result = _execute_command(cmd)
                            # Report result back to hosting
                            ok3, status3, _ = _http_post_json(
                                host_url + "/api/node/result",
                                {"id": NODE_ID, "cmd_id": cmd_id,
                                 "action": action, "vid": vid,
                                 "status": st, "result": result},
                                "RESULT")
                            if ok3 and status3 == 200:
                                dbg("NODE", f"  Result reported: {st}")
                            else:
                                log("NODE", f"  ⚠ Failed to report result (status={status3})")
            except Exception as e:
                dbg("NODE", f"Poll error: {e}")

        # Heartbeat interval
        time.sleep(5)

# ── MAIN ─────────────────────────────────────────────────────────────────────
def main():
    # Ghi PID file — `WinBoxes-Panel.sh --stop` dùng để dừng panel.
    # QEMU chạy daemonized (process riêng) → KHÔNG bị ảnh hưởng khi panel dừng.
    with open(PANEL_PID_FILE, "w") as f:
        f.write(str(os.getpid()))

    def _cleanup_pid():
        try: os.remove(PANEL_PID_FILE)
        except OSError: pass

    def _stop_handler(signum, frame):
        print(f"\n  ⏹ Dừng panel (signal {signum}) — VM vẫn chạy\n", flush=True)
        _cleanup_pid()
        raise SystemExit(0)

    signal.signal(signal.SIGTERM, _stop_handler)
    signal.signal(signal.SIGINT, _stop_handler)

    print(f"\n  WinBoxes-Panel  |  mode={MODE}  port={PORT}  v{WINBOX_VER}", flush=True)
    print(f"  data={DATA_DIR}  launcher={LAUNCHER}", flush=True)
    print(f"  winbox={WINBOX or '(none)'}", flush=True)
    if DEBUG:
        print(f"  debug=ON (HTTP request/response logging enabled)", flush=True)
    print(f"  ➜ http://localhost:{PORT}  (web khách hàng — KHÔNG cần login)\n", flush=True)
    if MODE == "vm":
        vm_mode_agent_loop()
        print("  ➜ Node agent: register + heartbeat 5s tới hosting (cgroup quota)", flush=True)
        print(f"  ➜ Retry: exponential backoff 5→10→20→40→60s nếu hosting offline", flush=True)
        if DEBUG:
            print(f"  ➜ DEBUG: full HTTP request/response logging enabled", flush=True)
    elif MODE == "hosting":
        nodes = load_nodes()
        print(f"  ➜ Hosting mode: {len(nodes)} node(s) trong registry", flush=True)
    srv = ThreadingHTTPServer(("0.0.0.0", PORT), Handler)
    try:
        srv.serve_forever()
    except SystemExit:
        pass
    finally:
        _cleanup_pid()
        srv.server_close()

if __name__ == "__main__":
    main()
