#!/usr/bin/env python3
# ════════════════════════════════════════════════════════════════════════════
#  resource_detect.py — Quota-aware resource detection (CRITICAL for scheduler)
#  ----------------------------------------------------------------------------
#  Trong Container/JupyterHub, /proc/cpuinfo & lscpu báo tài nguyên HOST (vd 32
#  core) thay vì quota thực (vd 4 core) → Scheduler phân bổ sai → oversubscribe
#  → VM crash/OOM. Module này ưu tiên cgroup quota TRƯỚC, fallback host info.
#
#  Thứ tự ưu tiên (quota luôn thắng host info):
#    CPU:   cgroup v2 cpu.max → cgroup v1 cfs_quota/period → cpuset → /proc
#    RAM:   cgroup v2 memory.max/high → cgroup v1 limit_in_bytes → /proc/meminfo
#    Disk:  XFS/EXT4 project quota → statvfs(data_dir)
#  Trả về tài nguyên THỰC TẾ node được cấp, không phải host.
# ════════════════════════════════════════════════════════════════════════════
import os, sys, json, subprocess, shutil

# ── CPUSET PARSER ────────────────────────────────────────────────────────────
def _parse_cpulist(s):
    """Parse '0-3,5,7-9' -> [0,1,2,3,5,7,8,9]."""
    out = []
    if not s or s.strip() in ("", "-", "\n"):
        return out
    for part in s.strip().split(","):
        part = part.strip()
        if not part:
            continue
        if "-" in part:
            try:
                a, b = part.split("-")
                out.extend(range(int(a), int(b) + 1))
            except ValueError:
                continue
        else:
            try:
                out.append(int(part))
            except ValueError:
                continue
    return out

# ── ENVIRONMENT DETECTION ────────────────────────────────────────────────────
def detect_environment():
    """
    Phát hiện môi trường chạy. Trả về dict chi tiết + string gọn.
    Kết hợp nhiều nguồn: /.dockerenv, /proc/1/environ, /proc/1/cgroup,
    KUBERNETES_SERVICE_HOST, JUPYTERHUB_USER, /run/.containerenv.
    """
    envs = set()
    is_root = os.geteuid() == 0

    # 1. Docker / Podman marker files
    if os.path.exists("/.dockerenv"):
        envs.add("docker")
    if os.path.exists("/run/.containerenv"):
        envs.add("podman")

    # 2. /proc/1/environ — LXC/Incus/OpenVZ set container= env var
    try:
        with open("/proc/1/environ", "rb") as f:
            raw = f.read()
        if b"container=lxc" in raw:
            envs.add("lxc")
        if b"container=incus" in raw or b"INCUS_INSTANCE" in raw:
            envs.add("incus")
        if b"container=" in raw and "lxc" not in envs and "incus" not in envs:
            envs.add("container")
    except (PermissionError, FileNotFoundError):
        pass

    # 3. /proc/1/cgroup — containers appear in cgroup paths
    try:
        with open("/proc/1/cgroup") as f:
            cg = f.read()
        if "docker" in cg or "containerd" in cg:
            envs.add("docker")
        if "kubepods" in cg or "kubepods.slice" in cg:
            envs.add("kubernetes")
        if "lxc" in cg:
            envs.add("lxc")
        if "machine.slice" in cg or "libpod" in cg:
            envs.add("podman")
        if "incus" in cg:
            envs.add("incus")
    except (PermissionError, FileNotFoundError):
        pass

    # 4. Kubernetes service env
    if os.environ.get("KUBERNETES_SERVICE_HOST"):
        envs.add("kubernetes")

    # 5. JupyterHub / JupyterLab
    if os.environ.get("JUPYTERHUB_USER") or os.environ.get("JUPYTERHUB_API_TOKEN"):
        envs.add("jupyterhub")
    if os.environ.get("JUPYTER_SERVER_ROOT") or os.environ.get("JUPYTERHUB_SERVICE_PREFIX"):
        envs.add("jupyterlab")
    if shutil.which("jupyter") and "jupyterlab" not in envs and "jupyterhub" not in envs:
        envs.add("jupyter")

    # 6. Rootless flag
    if not is_root:
        envs.add("rootless")

    # 7. Systemd-nspawn
    try:
        with open("/proc/1/comm") as f:
            if "systemd-nspawn" in f.read():
                envs.add("systemd-nspawn")
    except: pass

    env_list = sorted(envs)
    env_str = "+".join(env_list) if env_list else ("root" if is_root else "host")
    return {
        "environment": env_str,
        "envs": env_list,
        "is_root": is_root,
        "is_rootless": not is_root,
        "is_container": bool(envs & {"docker","podman","lxc","incus","kubernetes","container","systemd-nspawn"}),
    }

# ── CPU QUOTA DETECTION ─────────────────────────────────────────────────────
def detect_cpu():
    """
    Trả về số CPU core THỰC TẾ được cấp (quota), không phải host.
    Thứ tự: cgroup v2 cpu.max → cgroup v1 cfs_quota/period → cpuset → /proc.
    """
    source = "unknown"
    total = 1

    # --- cgroup v2: /sys/fs/cgroup/cpu.max = "quota period" hoặc "max period" ---
    try:
        with open("/sys/fs/cgroup/cpu.max") as f:
            parts = f.read().split()
        if len(parts) == 2:
            quota_str, period_str = parts
            if quota_str != "max":
                quota = int(quota_str)
                period = int(period_str)
                if quota > 0 and period > 0:
                    # Round up: 100000/100000=1, 200000/100000=2, 150000/100000=2
                    total = max(1, (quota + period - 1) // period)
                    source = "cgroup-v2-cpu.max"
                    return {"total": total, "source": source}
    except (FileNotFoundError, PermissionError, ValueError):
        pass

    # --- cgroup v1: cpu.cfs_quota_us / cpu.cfs_period_us ---
    for base in ["/sys/fs/cgroup/cpu", "/sys/fs/cgroup/cpu/cpu"]:
        try:
            with open(f"{base}/cpu.cfs_quota_us") as f:
                quota = int(f.read().strip())
            with open(f"{base}/cpu.cfs_period_us") as f:
                period = int(f.read().strip())
            if quota > 0 and period > 0 and quota < (2**31):
                total = max(1, (quota + period - 1) // period)
                source = "cgroup-v1-cfs"
                return {"total": total, "source": source}
        except (FileNotFoundError, PermissionError, ValueError):
            pass
    # also try nested (docker/k8s mount)
    try:
        with open("/sys/fs/cgroup/cpu/cpu.cfs_quota_us") as f:
            quota = int(f.read().strip())
        with open("/sys/fs/cgroup/cpu/cpu.cfs_period_us") as f:
            period = int(f.read().strip())
        if quota > 0 and period > 0 and quota < (2**31):
            total = max(1, (quota + period - 1) // period)
            source = "cgroup-v1-cfs"
            return {"total": total, "source": source}
    except (FileNotFoundError, PermissionError, ValueError):
        pass

    # --- cpuset (v2: cpuset.cpus.effective, v1: cpuset.cpuset.cpus) ---
    for path in ["/sys/fs/cgroup/cpuset.cpus.effective",
                 "/sys/fs/cgroup/cpuset/cpuset.cpus",
                 "/sys/fs/cgroup/cpuset.cpus"]:
        try:
            with open(path) as f:
                cpus = _parse_cpulist(f.read())
            if cpus:
                total = len(cpus)
                source = "cpuset"
                return {"total": total, "source": source}
        except (FileNotFoundError, PermissionError):
            pass

    # --- Fallback: host (chỉ khi KHÔNG có quota) ---
    try:
        total = os.cpu_count() or 1
        source = "host-os.cpu_count"
    except:
        total = 1
        source = "fallback-1"
    return {"total": total, "source": source}

# ── CPU USAGE (realtime, /proc/stat giới hạn theo quota) ──────────────────────
def cpu_usage_percent():
    """CPU usage %. Đọc 2 lần /proc/stat với delay 0.1s."""
    import time
    def read_stat():
        try:
            with open("/proc/stat") as f:
                return [int(x) for x in f.readline().split()[1:5]]
        except:
            return [0,0,0,0]
    a = read_stat()
    time.sleep(0.1)
    b = read_stat()
    total = sum(b) - sum(a)
    idle = b[3] - a[3]
    return round((1 - idle/total) * 100, 1) if total > 0 else 0.0

# ── RAM QUOTA DETECTION ─────────────────────────────────────────────────────
def detect_ram():
    """
    Trả về RAM (bytes) THỰC TẾ được cấp.
    Thứ tự: cgroup v2 memory.max → memory.high → cgroup v1 limit_in_bytes → /proc.
    """
    source = "unknown"

    # --- cgroup v2: memory.max (hard limit) ---
    try:
        with open("/sys/fs/cgroup/memory.max") as f:
            v = f.read().strip()
        if v and v != "max":
            limit = int(v)
            if limit > 0 and limit < (2**60):
                return {"total": limit, "source": "cgroup-v2-memory.max"}
    except (FileNotFoundError, PermissionError, ValueError):
        pass

    # --- cgroup v2: memory.high (throttling limit, softer) ---
    try:
        with open("/sys/fs/cgroup/memory.high") as f:
            v = f.read().strip()
        if v and v != "max":
            limit = int(v)
            if limit > 0 and limit < (2**60):
                return {"total": limit, "source": "cgroup-v2-memory.high"}
    except (FileNotFoundError, PermissionError, ValueError):
        pass

    # --- cgroup v1: memory.limit_in_bytes ---
    try:
        with open("/sys/fs/cgroup/memory/memory.limit_in_bytes") as f:
            limit = int(f.read().strip())
        # 2^60 (9.2 exabyte) = "unlimited" sentinel — bỏ qua
        if 0 < limit < (2**60):
            return {"total": limit, "source": "cgroup-v1-limit_in_bytes"}
    except (FileNotFoundError, PermissionError, ValueError):
        pass

    # --- Fallback: /proc/meminfo ---
    try:
        with open("/proc/meminfo") as f:
            for line in f:
                if line.startswith("MemTotal:"):
                    kb = int(line.split()[1])
                    return {"total": kb * 1024, "source": "host-meminfo"}
    except:
        pass
    return {"total": 0, "source": "fallback-0"}

def ram_usage_bytes():
    """RAM đang dùng (bytes). Cgroup v2 memory.current ưu tiên, fallback /proc."""
    # cgroup v2: memory.current
    try:
        with open("/sys/fs/cgroup/memory.current") as f:
            return int(f.read().strip())
    except (FileNotFoundError, PermissionError, ValueError):
        pass
    # cgroup v1: memory.usage_in_bytes
    try:
        with open("/sys/fs/cgroup/memory/memory.usage_in_bytes") as f:
            return int(f.read().strip())
    except (FileNotFoundError, PermissionError, ValueError):
        pass
    # Fallback: /proc/meminfo (MemTotal - MemAvailable)
    try:
        with open("/proc/meminfo") as f:
            lines = f.read().splitlines()
        d = {}
        for l in lines:
            if ":" in l:
                k, v = l.split(":", 1)
                d[k.strip()] = int(v.split()[0]) * 1024
        total = d.get("MemTotal", 0)
        avail = d.get("MemAvailable", d.get("MemFree", 0))
        return max(0, total - avail)
    except:
        return 0

# ── DISK QUOTA DETECTION ────────────────────────────────────────────────────
def detect_disk(path="."):
    """
    Trả về (total_bytes, free_bytes) cho path.
    Ưu tiên: XFS project quota → EXT4 quota → statvfs (real filesystem).
    """
    path = os.path.abspath(path or ".")

    # --- XFS quota (xfs_quota -x -c 'report') ---
    if shutil.which("xfs_quota"):
        try:
            r = subprocess.run(
                ["xfs_quota", "-x", "-c", "report -N -b"],
                capture_output=True, text=True, timeout=2)
            # parse lines: "<fs> <path> <used> <soft> <hard> <warns> <grace>"
            for line in r.stdout.splitlines():
                parts = line.split()
                if len(parts) >= 5 and path in line:
                    used = int(parts[2]) * 1024
                    hard = int(parts[4]) * 1024
                    if hard > 0:
                        return {"total": hard, "free": max(0, hard-used),
                                "source": "xfs-quota", "used": used}
        except (subprocess.TimeoutExpired, ValueError, FileNotFoundError):
            pass

    # --- EXT4 quota (quota -uv) ---
    if shutil.which("quota"):
        try:
            r = subprocess.run(["quota", "-uv"], capture_output=True, text=True, timeout=2)
            for line in r.stdout.splitlines():
                parts = line.split()
                if len(parts) >= 4:
                    used = int(parts[0]) * 1024
                    hard = int(parts[2]) * 1024
                    if hard > 0:
                        return {"total": hard, "free": max(0, hard-used),
                                "source": "ext4-quota", "used": used}
        except (subprocess.TimeoutExpired, ValueError, FileNotFoundError):
            pass

    # --- Fallback: statvfs (real filesystem of data dir) ---
    try:
        st = os.statvfs(path)
        total = st.f_blocks * st.f_frsize
        free = st.f_bavail * st.f_frsize
        used = total - free
        return {"total": total, "free": free, "used": used, "source": "statvfs"}
    except:
        return {"total": 0, "free": 0, "used": 0, "source": "fallback-0"}

# ── LOAD AVERAGE ────────────────────────────────────────────────────────────
def load_average():
    try:
        return list(os.getloadavg())
    except:
        return [0.0, 0.0, 0.0]

# ── NETWORK ─────────────────────────────────────────────────────────────────
def net_stats():
    """Trả về (rx_bytes, tx_bytes) tổng tất cả interface (trừ lo)."""
    rx = tx = 0
    try:
        with open("/proc/net/dev") as f:
            for line in f:
                if ":" not in line:
                    continue
                name = line.split(":")[0].strip()
                if name == "lo":
                    continue
                parts = line.split(":")[1].split()
                if len(parts) >= 9:
                    rx += int(parts[0])
                    tx += int(parts[8])
    except:
        pass
    return {"rx_bytes": rx, "tx_bytes": tx}

# ── VM COUNT (đếm qemu process hoặc PID files) ───────────────────────────────
def vm_count(vm_dir=None):
    """Đếm số VM đang chạy trên node này (qua PID files còn sống)."""
    count = 0
    if not vm_dir:
        return count
    try:
        import glob
        for pf in glob.glob(os.path.join(vm_dir, "vm_*.pid")):
            try:
                with open(pf) as f:
                    pid = int(f.read().strip())
                os.kill(pid, 0)
                count += 1
            except (ValueError, ProcessLookupError, PermissionError, FileNotFoundError):
                pass
    except:
        pass
    return count

# ── UPTIME ───────────────────────────────────────────────────────────────────
def uptime_seconds():
    try:
        with open("/proc/uptime") as f:
            return int(float(f.read().split()[0]))
    except:
        return 0

# ── OS INFO ──────────────────────────────────────────────────────────────────
def os_info():
    info = {"name": "Linux", "version": "", "id": "linux"}
    try:
        with open("/etc/os-release") as f:
            for line in f:
                if "=" in line:
                    k, v = line.strip().split("=", 1)
                    v = v.strip('"').strip("'")
                    if k == "PRETTY_NAME": info["name"] = v
                    elif k == "VERSION": info["version"] = v
                    elif k == "ID": info["id"] = v
    except:
        pass
    return info

def arch():
    import platform
    return platform.machine()

# ── FULL SNAPSHOT (gọi cho register + heartbeat) ────────────────────────────
def snapshot(data_dir=None, winbox_version="3.2"):
    """
    Snapshot tài nguyên đầy đủ cho register/heartbeat.
    Bao gồm: env, cpu quota+usage, ram quota+usage, disk quota+usage,
    load, net, vm_count, uptime, os, arch, version.
    """
    env = detect_environment()
    cpu = detect_cpu()
    ram = detect_ram()
    disk = detect_disk(data_dir or os.path.expanduser("~"))
    ram_used = ram_usage_bytes()
    cpu_pct = cpu_usage_percent()
    return {
        "environment": env["environment"],
        "is_container": env["is_container"],
        "is_rootless": env["is_rootless"],
        "cpu": {
            "total": cpu["total"],
            "source": cpu["source"],
            "usage_percent": cpu_pct,
            "free": max(0, cpu["total"] - int(cpu_pct / 100 * cpu["total"])),
        },
        "ram": {
            "total": ram["total"],
            "source": ram["source"],
            "used": ram_used,
            "free": max(0, ram["total"] - ram_used),
            "usage_percent": round(ram_used / ram["total"] * 100, 1) if ram["total"] else 0,
        },
        "disk": {
            "total": disk["total"],
            "free": disk["free"],
            "used": disk["used"],
            "source": disk["source"],
            "usage_percent": round(disk["used"] / disk["total"] * 100, 1) if disk["total"] else 0,
        },
        "load_average": load_average(),
        "net": net_stats(),
        "vm_count": vm_count(data_dir),
        "uptime": uptime_seconds(),
        "os": os_info(),
        "arch": arch(),
        "winbox_version": winbox_version,
        "timestamp": int(__import__("time").time()),
    }

# ── CLI (test độc lập: python3 resource_detect.py) ───────────────────────────
if __name__ == "__main__":
    print(json.dumps(snapshot(), indent=2))
