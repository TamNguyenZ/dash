#!/usr/bin/env python3
# ════════════════════════════════════════════════════════════════════════════
#  scheduler.py — Best Fit VM scheduler cho WinBoxes-Panel
#  ----------------------------------------------------------------------------
#  Người dùng CHỈ chọn CPU/RAM/Disk/Image. Scheduler tự:
#    1. Lấy danh sách Node Online (heartbeat < 30s)
#    2. Loại Node Offline
#    3. Loại Node thiếu CPU quota
#    4. Loại Node thiếu RAM quota
#    5. Loại Node thiếu Disk quota
#    6. Loại Node lỗi/resource-detection-failed
#    7. Best Fit: chọn node CÓ VỪA ĐỦ (giảm lãng phí), KHÔNG random
#  Nếu không còn node phù hợp → trả "no_node" (panel hiển thị "Đang hết máy").
# ════════════════════════════════════════════════════════════════════════════
import time

OFFLINE_THRESHOLD = 30  # giây — node không heartbeat 30s = offline

class SchedulerError(Exception):
    """Không có node phù hợp. message = yêu cầu cụ thể."""
    pass

def _is_online(node):
    """Node online nếu heartbeat trong 30s gần đây."""
    last = node.get("last_seen") or node.get("timestamp") or 0
    return (time.time() - last) < OFFLINE_THRESHOLD

def _cpu_free(node):
    """CPU core free = total - vm_count (mỗi VM dùng ít nhất 1 core)."""
    cpu = node.get("cpu", {})
    total = cpu.get("total", 0)
    # free = total - (vm đang chạy + usage% quy đổi)
    vm_count = node.get("vm_count", 0)
    # ước lượng: mỗi VM đang chạy chiếm ~1 core trung bình
    # dùng usage_percent để chính xác hơn nếu có
    usage_pct = cpu.get("usage_percent", 0)
    used = max(vm_count, int(total * usage_pct / 100))
    return max(0, total - used)

def _ram_free(node):
    """RAM free (bytes)."""
    ram = node.get("ram", {})
    return ram.get("free", 0)

def _disk_free(node):
    """Disk free (bytes)."""
    disk = node.get("disk", {})
    return disk.get("free", 0)

def _node_healthy(node):
    """Node không lỗi: có cpu/ram/disk data + source không phải fallback-0."""
    cpu = node.get("cpu", {})
    ram = node.get("ram", {})
    disk = node.get("disk", {})
    if not cpu or not ram or not disk:
        return False
    if cpu.get("total", 0) <= 0:
        return False
    if ram.get("total", 0) <= 0:
        return False
    # source fallback-0 = detection hoàn toàn thất bại
    if ram.get("source") == "fallback-0" and cpu.get("source", "").startswith("fallback"):
        return False
    return True

def schedule(nodes, req_cpu, req_ram_bytes, req_disk_bytes):
    """
    Chọn node phù hợp nhất cho VM yêu cầu.

    Args:
        nodes: list of node dicts (từ registry, có heartbeat data)
        req_cpu: int — số CPU core yêu cầu
        req_ram_bytes: int — RAM bytes yêu cầu
        req_disk_bytes: int — disk bytes yêu cầu

    Returns:
        node dict (node được chọn)

    Raises:
        SchedulerError: không có node phù hợp. .reason = chi tiết.
    """
    if not nodes:
        raise SchedulerError("Chưa có Node nào đăng ký. Vui lòng chạy WinBoxes ở VM Mode trên máy khác.")

    candidates = []
    reject_reasons = []

    for node in nodes:
        nid = node.get("id", "?")

        # Bước 2: loại offline
        if not _is_online(node):
            reject_reasons.append(f"{nid}: offline (không heartbeat)")
            continue

        # Bước 6: loại node lỗi / detection failed
        if not _node_healthy(node):
            reject_reasons.append(f"{nid}: resource detection failed")
            continue

        # Bước 3: loại thiếu CPU
        cpu_free = _cpu_free(node)
        if cpu_free < req_cpu:
            reject_reasons.append(f"{nid}: CPU không đủ (free {cpu_free} < yêu cầu {req_cpu})")
            continue

        # Bước 4: loại thiếu RAM
        ram_free = _ram_free(node)
        if ram_free < req_ram_bytes:
            reject_reasons.append(
                f"{nid}: RAM không đủ (free {ram_free//1e9:.1f}GB < yêu cầu {req_ram_bytes/1e9:.1f}GB)")
            continue

        # Bước 5: loại thiếu Disk
        disk_free = _disk_free(node)
        if disk_free < req_disk_bytes:
            reject_reasons.append(
                f"{nid}: Disk không đủ (free {disk_free//1e9:.1f}GB < yêu cầu {req_disk_bytes/1e9:.1f}GB)")
            continue

        candidates.append(node)

    if not candidates:
        # Không còn node phù hợp — không crash, báo chi tiết
        raise SchedulerError(
            "Không có Node nào đáp ứng cấu hình này.\n"
            f"Yêu cầu: CPU {req_cpu} core · RAM {req_ram_bytes/1e9:.1f} GB · Disk {req_disk_bytes/1e9:.1f} GB\n"
            + ("\n".join("  • " + r for r in reject_reasons) if reject_reasons else "")
        )

    # Bước 7: Best Fit — chọn node CÓ VỪA ĐỦ (slack nhỏ nhất)
    def fit_score(node):
        """
        Score = tổng "slack" sau khi đặt VM. Nhỏ hơn = vừa đủ hơn = ưu tiên.
        Normalize về đơn vị chung (CPU core + GB) để so sánh công bằng.
        """
        cpu_slack = _cpu_free(node) - req_cpu
        ram_slack_gb = (_ram_free(node) - req_ram_bytes) / 1e9
        disk_slack_gb = (_disk_free(node) - req_disk_bytes) / 1e9
        # Weight: CPU quan trọng nhất (khan hiếm), rồi RAM, rồi Disk
        return cpu_slack * 4 + ram_slack_gb * 1 + disk_slack_gb * 0.2

    candidates.sort(key=fit_score)
    return candidates[0]

# ── CLI test ─────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    # Node A: 8 CPU free, 10GB RAM, 100GB disk (vừa đủ)
    # Node B: 32 CPU free, 64GB RAM, 500GB disk (quá dư)
    # Yêu cầu: 2 CPU, 2GB, 40GB → Best Fit chọn A
    nodes = [
        {"id":"A","last_seen":time.time(),"cpu":{"total":8,"usage_percent":0,"free":8},
         "ram":{"total":10*1e9,"free":10*1e9},"disk":{"total":100*1e9,"free":100*1e9},
         "vm_count":0},
        {"id":"B","last_seen":time.time(),"cpu":{"total":32,"usage_percent":0,"free":32},
         "ram":{"total":64*1e9,"free":64*1e9},"disk":{"total":500*1e9,"free":500*1e9},
         "vm_count":0},
    ]
    chosen = schedule(nodes, 2, 2*10**9, 40*10**9)
    print(f"Chosen: {chosen['id']} (expected A)")
    # Test no-fit
    try:
        schedule(nodes, 64, 128*10**9, 1000*10**9)
    except SchedulerError as e:
        print(f"No-fit OK: {str(e)[:80]}...")
