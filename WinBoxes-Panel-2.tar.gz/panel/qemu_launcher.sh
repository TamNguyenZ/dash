#!/usr/bin/env bash
# ════════════════════════════════════════════════════════════════════════════
#  qemu_launcher.sh — Panel-native QEMU launcher
#  ----------------------------------------------------------------------------
#  Mirror cấu hình QEMU của winboxes-stable-3-2.sh (machine q35, virtio-blk,
#  virtio-net, iothread, user-net + hostfwd RDP, QMP socket) NHƯNG thêm:
#    - VNC display PER-INSTANCE (-vnc :N) -> multi-VM không xung đột
#    - VNC WebSocket (-vnc :N,websocket=WS) -> noVNC kết nối trực tiếp ws://
#  WinBoxes gốc hardcode `-vnc :0` (single-instance), panel sửa điều này.
#
#  Gọi bởi backend.py. KHÔNG tự tải ảnh — ảnh phải có sẵn (download qua WinBoxes
#  hoặc đặt tay). Panel chỉ khởi động QEMU.
#
#  Args:
#    qemu_launcher.sh start   <id> <img> <ram_gb> <cpu> <rdp_port> <vnc_display> <ws_port> <machine> <uefi> [fwd:host:guest ...]
#    qemu_launcher.sh stop    <id>
#    qemu_launcher.sh restart <id>
#    qemu_launcher.sh status  <id>
#    qemu_launcher.sh qmp     <id> <json>
#    qemu_launcher.sh snapshot <id> save|load|list [name] <img>
#    qemu_launcher.sh resize  <id> <img> <+NG>
# ════════════════════════════════════════════════════════════════════════════
set -uo pipefail

G='\033[1;32m'; Y='\033[1;33m'; R='\033[1;31m'; B='\033[1;34m'; W='\033[0m'
ok(){ printf "${G}✔${W} %s\n" "$*"; }
inf(){ printf "${B}ℹ${W}  %s\n" "$*"; }
warn(){ printf "${Y}⚠${W}  %s\n" "$*"; }
err(){ printf "${R}✘${W} %s\n" "$*" >&2; }

DATA_DIR="${WINBOXES_PANEL_DATA:-${HOME}/.winboxes-panel}"
VM_DIR="${DATA_DIR}/vm"; mkdir -p "$VM_DIR"
LOG_DIR="${DATA_DIR}/logs"; mkdir -p "$LOG_DIR"
STATE_DIR="${DATA_DIR}/state"; mkdir -p "$STATE_DIR"

pid_file(){  echo "${VM_DIR}/vm_$1.pid"; }
qmp_sock(){  echo "${VM_DIR}/vm_$1.qmp"; }
state_file(){ echo "${STATE_DIR}/vm_$1.json"; }
log_file(){  echo "${LOG_DIR}/vm_$1.log"; }

# Tìm QEMU binary (cùng thứ tự ưu tiên với WinBoxes)
resolve_qemu(){
    for q in "${QEMU_BIN:-}" \
             "${HOME}/qemu-static/bin/qemu-system-x86_64" \
             "${HOME}/qemu-optimized/bin/qemu-system-x86_64" \
             "/opt/qemu-optimized/bin/qemu-system-x86_64" \
             "$(command -v qemu-system-x86_64 2>/dev/null)"; do
        [ -n "$q" ] && [ -x "$q" ] && { echo "$q"; return 0; }
    done
    return 1
}
resolve_qemu_img(){
    for qi in "$(dirname "$(resolve_qemu 2>/dev/null || echo /x)")/qemu-img" \
             "${HOME}/qemu-static/bin/qemu-img" \
             "${HOME}/qemu-optimized/bin/qemu-img" \
             "/opt/qemu-optimized/bin/qemu-img" \
             "$(command -v qemu-img 2>/dev/null)"; do
        [ -x "$qi" ] && "$qi" --version >/dev/null 2>&1 && { echo "$qi"; return 0; }
    done
    return 1
}

# KVM available?
has_kvm(){
    [ -r /dev/kvm ] && [ -w /dev/kvm ]
}

# Ghi state JSON cho backend đọc
write_state(){
    local id="$1"; shift
    printf '%s\n' "$1" > "$(state_file "$id")"
}

is_running(){
    local id="$1" pf; pf="$(pid_file "$id")"
    [ -f "$pf" ] || return 1
    local p; p="$(cat "$pf" 2>/dev/null)"
    [ -n "$p" ] && kill -0 "$p" 2>/dev/null
}

# ── START ───────────────────────────────────────────────────────────────────
cmd_start(){
    local id="$1" img="$2" ram_gb="$3" cpu="$4" rdp_port="$5"
    local vnc_display="$6" ws_port="$7" machine="$8" uefi="$9"
    shift 9
    local fwds=("$@")

    local qb qi
    qb="$(resolve_qemu)" || { err "QEMU chưa cài. Chạy winboxes.sh --build hoặc cài qemu-system-x86_64."; return 1; }
    qi="$(resolve_qemu_img)" || qi=""

    [ -f "$img" ] || { err "Ảnh không tồn tại: $img"; return 1; }

    # Dừng VM cũ nếu đang chạy
    if is_running "$id"; then
        warn "VM $id đang chạy — dừng trước."
        cmd_stop "$id" >/dev/null 2>&1; sleep 2
    fi

    # Format ảnh
    local fmt="raw"
    [ -n "$qi" ] && fmt="$("$qi" info "$img" 2>/dev/null | awk -F': ' '/file format/{print $2; exit}')"
    [ -z "$fmt" ] && fmt="raw"

    # Acceleration
    local accel cpu_model smp_args machine_args
    if has_kvm; then
        accel="-enable-kvm"
        cpu_model="-cpu host"
        smp_args="-smp $cpu"
        machine_args="-machine ${machine},hpet=off"
    else
        # TCG — mirror WinBoxes TCG flags (đơn giản hóa, không replicate model-id)
        accel="-accel tcg,thread=multi"
        cpu_model="-cpu max,hypervisor=off,tsc=on"
        smp_args="-smp ${cpu},cores=${cpu},threads=1,sockets=1"
        machine_args="-machine ${machine},hpet=off,vmport=off,mem-merge=off"
    fi

    # Network + forwards: RDP (host rdp_port -> guest 3389) + extras (host:guest)
    local netdev="user,id=n0,hostfwd=tcp::${rdp_port}-:3389"
    for f in "${fwds[@]:-}"; do
        [ -z "$f" ] && continue
        # fwd format: host:guest
        local h="${f%%:*}" g="${f##*:}"
        netdev="$netdev,hostfwd=tcp::${h}-:${g}"
    done

    # UEFI (OVMF) nếu ảnh cần (vd Win11)
    local uefi_args=""
    if [ "$uefi" = "yes" ] || [ "$uefi" = "1" ]; then
        local ovmf=""
        for p in "/usr/share/OVMF/OVMF_CODE.fd" \
                 "/usr/share/qemu/OVMF_CODE.fd" \
                 "${HOME}/ovmf/OVMF_CODE.fd" \
                 "${DATA_DIR}/ovmf/OVMF_CODE.fd"; do
            [ -f "$p" ] && { ovmf="$p"; break; }
        done
        if [ -n "$ovmf" ]; then
            uefi_args="-drive if=pflash,format=raw,readonly=on,file=${ovmf}"
            warn "UEFI mode (OVMF: $ovmf)"
        else
            warn "Ảnh cần UEFI nhưng không tìm thấy OVMF — có thể không boot."
        fi
    fi

    local pid qmp
    pid="$(pid_file "$id")"; qmp="$(qmp_sock "$id")"
    rm -f "$pid" "$qmp"

    inf "Khởi động QEMU (id=$id, ${cpu} vCPU, ${ram_gb}GB, $machine, $fmt)"
    inf "VNC raw :5$((590+vnc_display))  WS:$ws_port  RDP:$rdp_port  Ảnh:$img"

    # Lệnh QEMU — mirror WinBoxes + thêm -vnc :N,websocket=WS
    "$qb" \
        $machine_args \
        $cpu_model \
        $smp_args \
        -m "${ram_gb}G" \
        $accel \
        -rtc base=localtime,clock=host \
        -object iothread,id=io1 \
        -drive file="$img",if=none,id=disk0,cache=unsafe,aio=threads,format="$fmt" \
        -device virtio-blk-pci,drive=disk0,iothread=io1,num-queues=4,queue-size=256 \
        -netdev "$netdev" \
        -device virtio-net-pci,netdev=n0 \
        -vga virtio \
        -vnc ":${vnc_display}",websocket="$ws_port" \
        $uefi_args \
        -device nec-usb-xhci \
        -device usb-tablet \
        -qmp "unix:${qmp},server,nowait" \
        -pidfile "$pid" \
        -daemonize \
        >"$(log_file "$id")" 2>&1

    local rc=$?
    sleep 2
    local rpid=""; [ -f "$pid" ] && rpid="$(cat "$pid" 2>/dev/null)"

    if [ $rc -eq 0 ] && [ -n "$rpid" ] && kill -0 "$rpid" 2>/dev/null; then
        ok "VM $id chạy (PID $rpid)"
        write_state "$id" "$(cat <<EOF
{"running":true,"pid":$rpid,"id":$id,"rdp_port":$rdp_port,"vnc_display":$vnc_display,"vnc_raw_port":$((5900+vnc_display)),"ws_port":$ws_port,"started_at":$(date +%s),"image":"$img"}
EOF
)"
        return 0
    else
        err "QEMU không khởi động (rc=$rc). Xem log: $(log_file "$id")"
        tail -n 20 "$(log_file "$id")" 2>/dev/null
        write_state "$id" "{\"running\":false,\"id\":$id,\"error\":\"qemu failed rc=$rc\"}"
        return 1
    fi
}

# ── STOP (ACPI graceful) ────────────────────────────────────────────────────
cmd_stop(){
    local id="$1"
    local qmp pid rpid
    qmp="$(qmp_sock "$id")"; pid="$(pid_file "$id")"
    rpid=""; [ -f "$pid" ] && rpid="$(cat "$pid" 2>/dev/null)"
    if [ -n "$rpid" ] && kill -0 "$rpid" 2>/dev/null; then
        inf "ACPI shutdown VM $id..."
        if [ -S "$qmp" ] && command -v socat >/dev/null 2>&1; then
            printf '{"execute":"qmp_capabilities"}\n{"execute":"system_powerdown"}\n' \
                | socat - UNIX-CONNECT:"$qmp" 2>/dev/null || true
        fi
        for i in $(seq 1 30); do
            kill -0 "$rpid" 2>/dev/null || break
            sleep 1
        done
        kill -0 "$rpid" 2>/dev/null && { warn "Graceful timeout — kill -9"; kill -9 "$rpid" 2>/dev/null || true; }
        ok "VM $id đã dừng"
    else
        warn "VM $id không chạy"
    fi
    rm -f "$pid" "$qmp"
    write_state "$id" "{\"running\":false,\"id\":$id,\"stopped_at\":$(date +%s)}"
}

# ── RESTART ─────────────────────────────────────────────────────────────────
cmd_restart(){ local id="$1"; cmd_stop "$id" >/dev/null 2>&1; sleep 2; echo "restart-only (cần start lại qua backend)"; }

# ── STATUS ──────────────────────────────────────────────────────────────────
cmd_status(){
    local id="$1"
    local running=false rpid=""
    if is_running "$id"; then running=true; rpid="$(cat "$(pid_file "$id")" 2>/dev/null)"; fi
    if $running; then
        write_state "$id" "$(cat "$(state_file "$id")" 2>/dev/null | sed 's/"running":false/"running":true/; s/"running":[^,]*/"running":true/' || echo "{\"running\":true,\"id\":$id,\"pid\":$rpid}")"
        echo "{\"running\":true,\"id\":$id,\"pid\":$rpid}"
    else
        write_state "$id" "{\"running\":false,\"id\":$id}"
        echo "{\"running\":false,\"id\":$id}"
    fi
}

# ── QMP (gửi JSON raw) ─────────────────────────────────────────────────────
cmd_qmp(){
    local id="$1" json="$2"
    local qmp; qmp="$(qmp_sock "$id")"
    [ -S "$qmp" ] || { err "QMP socket không tồn tại"; echo '{"error":"no qmp socket"}'; return 1; }
    command -v socat >/dev/null 2>&1 || { err "cần socat"; return 1; }
    printf '{"execute":"qmp_capabilities"}\n%s\n' "$json" | socat - UNIX-CONNECT:"$qmp" 2>/dev/null
}

# ── SNAPSHOT ────────────────────────────────────────────────────────────────
cmd_snapshot(){
    local id="$1" action="$2" name="${3:-}" img="${4:-}"
    local qi; qi="$(resolve_qemu_img)" || { err "qemu-img chưa cài"; return 1; }
    local qmp; qmp="$(qmp_sock "$id")"
    case "$action" in
        save)
            [ -S "$qmp" ] && printf '{"execute":"qmp_capabilities"}\n{"execute":"savevm","arguments":{"name":"%s"}}\n' "$name" \
                | socat - UNIX-CONNECT:"$qmp" 2>/dev/null
            ok "Snapshot saved: $name" ;;
        load)
            [ -S "$qmp" ] && printf '{"execute":"qmp_capabilities"}\n{"execute":"loadvm","arguments":{"name":"%s"}}\n' "$name" \
                | socat - UNIX-CONNECT:"$qmp" 2>/dev/null
            ok "Snapshot loaded: $name" ;;
        list)
            [ -n "$img" ] && [ -f "$img" ] && "$qi" snapshot -l "$img" 2>/dev/null || echo "(không có ảnh để list)" ;;
    esac
}

# ── RESIZE ──────────────────────────────────────────────────────────────────
cmd_resize(){
    local id="$1" img="$2" size="$3"
    [ -f "$img" ] || { err "Ảnh không tồn tại: $img"; return 1; }
    is_running "$id" && { err "Dừng VM trước khi resize."; return 1; }
    local qi; qi="$(resolve_qemu_img)" || return 1
    "$qi" resize "$img" "$size" && ok "Resize xong: $img += $size"
}

# ── MAIN ───────────────────────────────────────────────────────────────────
[ $# -eq 0 ] && { echo "Usage: qemu_launcher.sh <start|stop|restart|status|qmp|snapshot|resize> ..."; exit 1; }
cmd="$1"; shift
case "$cmd" in
    start)    cmd_start "$@" ;;
    stop)     cmd_stop "$@" ;;
    restart)  cmd_restart "$@" ;;
    status)   cmd_status "$@" ;;
    qmp)      cmd_qmp "$@" ;;
    snapshot) cmd_snapshot "$@" ;;
    resize)   cmd_resize "$@" ;;
    *) err "Lệnh không rõ: $cmd"; exit 1 ;;
esac
