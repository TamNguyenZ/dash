# WinBoxes-Panel

Web Dashboard điều khiển **WinBoxes** (QEMU Windows VM). Phong cách Cloud/VPS provider:
dark mode, glassmorphism, sidebar, cards, wizard, noVNC console, live logs, multi-node.

> Phân tích từ `winboxes-stable-3-2.sh`. Panel điều khiển WinBoxes qua Web UI —
> không yêu cầu command line. **KHÔNG chạy QEMU hay tải ảnh khi khởi động panel** —
> QEMU/ảnh chỉ chạy khi user chủ động tạo/khởi động VM.

## Kiến trúc

```
WinBoxes-Panel/
├── WinBoxes-Panel.sh         # Entry: chọn mode, env detect, launch backend, --stop/--status
└── panel/
    ├── backend.py            # REST API + SSE + JWT + node registry + scheduler routing
    ├── resource_detect.py    # cgroup quota detection (CPU/RAM/Disk THỰC TẾ, không host)
    ├── scheduler.py          # Best Fit scheduler (loại offline/quota thiếu, chọn node vừa đủ)
    ├── qemu_launcher.sh      # QEMU launcher: mirror WinBoxes + VNC-websocket per-instance
    └── static/
        ├── index.html        # SPA: dashboard, VM, wizard, nodes (admin), logs, settings
        └── console.html      # noVNC console (local + CDN fallback)
```

## Bỏ admin/token — Web cho khách hàng

- **KHÔNG có login/token** — web mở cho khách hàng, vào thẳng dashboard
- **KHÔNG có admin role** — không phân quyền
- **KHÔNG có trang Nodes** — khách không thấy node/hostname/địa chỉ máy chủ
- **`/api/vm` ẩn trường `node`** — khách chỉ thấy VM của mình
- Scheduler nội bộ tự chọn node (Best Fit), khách không biết VM chạy ở đâu
- **`/api/nodes`, `/api/auth/*` đã xoá** khỏi API khách hàng

Node↔Hosting vẫn dùng shared secret nội bộ (`node_key`) — chỉ giữa server, khách không bao giờ thấy. Hosting operator sinh `node_key` khi khởi động (hiện ra 1 lần để chia sẻ cho node operator). VM Mode node nhập `node_key` khi đăng ký.

**User KHÔNG chọn Node.** User chỉ chọn CPU/RAM/Disk/Image. Scheduler tự:
1. Lấy Node Online (heartbeat < 30s)
2. Loại Offline
3. Loại thiếu CPU quota
4. Loại thiếu RAM quota
5. Loại thiếu Disk quota
6. Loại lỗi/resource-detection-failed
7. **Best Fit**: chọn node CÓ VỪA ĐỦ (slack nhỏ nhất), không random

**Resource Quota Detection (CRITICAL)** — `resource_detect.py` ưu tiên cgroup TRƯỚC host info:
- CPU: `cgroup v2 cpu.max` → `cgroup v1 cfs_quota/period` → `cpuset` → `/proc` (fallback)
- RAM: `cgroup v2 memory.max/high` → `cgroup v1 limit_in_bytes` → `/proc/meminfo` (fallback)
- Disk: XFS/EXT4 project quota → `statvfs` (fallback)

Ví dụ: Container 4 core / 8GB RAM → Node báo **4 core / 8GB** (không phải host 32 core / 64GB). Scheduler chỉ dùng quota thật.

**Node Auto Discovery** — VM Mode node tự register + heartbeat 5s, gửi full resource snapshot. Hosting auto-add vào scheduler, không cần restart. Node mất heartbeat 30s → Offline; heartbeat quay lại → Online (recovery, không cần register lại).

**Không còn Node phù hợp** → không crash, hiển thị "Đang hết máy" + yêu cầu cụ thể + lý do loại từng node.

**Token reset** — đã bỏ (không còn token/admin).

**`--stop` dừng panel, giữ VM** — QEMU daemonized nên độc lập với panel. Dừng panel
chỉ tắt web UI + node heartbeat, VM vẫn chạy. Khởi động lại → VM tự xuất hiện lại.

**Hai chế độ:**
- **Hosting Mode** — máy chủ chính: lưu VM, quản lý node, API, noVNC. Các VM-Mode node đăng ký lên đây.
- **VM Mode** — node chạy rootless/container/JupyterHub, đăng ký lên Hosting, heartbeat 15s.

**Panel-native launcher** (`qemu_launcher.sh`) mirror cấu hình QEMU của WinBoxes
(machine q35, virtio-blk, virtio-net, iothread, user-net + hostfwd RDP, QMP socket)
NHƯNG thêm `-vnc :N,websocket=PORT` per-instance → noVNC kết nối trực tiếp, hỗ trợ
multi-VM (WinBoxes gốc hardcode `-vnc :0` single-instance). Build/download/PGO/BOLT
delegate sang `winboxes.sh`.

## Tính năng (port đầy đủ từ WinBoxes)
- 6 preset Windows (Server 2012 R2/2022, Win11 LTSB, Win10 LTSB/LTSC/2022)
- Start/Stop/Restart (ACPI graceful qua QMP `system_powerdown` + force kill)
- Multi-instance: RDP=3388+id, VNC display=id-1, WS=6000+id
- Snapshot save/load/list (QMP `savevm`/`loadvm` + `qemu-img snapshot -l`)
- Resize disk (`+NG`, VM phải tắt)
- Clone, Rename, Delete
- Port forwarding (host:guest, TCP)
- noVNC console (fullscreen, clipboard, keyboard bar, auto-reconnect)
- Live logs (SSE realtime + search + download)
- Monitoring: CPU/RAM/Disk/Network/Uptime + VM status realtime
- Node manager (Hosting mode): online nodes, env, latency
- Settings: theme, language, auto-refresh, defaults
- Wizard tạo VM 6 bước (tên → RAM → CPU → disk → image → xác nhận)
- Auth: JWT (HS256), login admin/<token>
- Tự phát hiện: rootless, Docker, LXC, k8s, JupyterHub

## Caveat (từ phân tích source v3.2 — KHÔNG expose)
Các tính năng sau chỉ là **stub/vestigial** trong WinBoxes v3.2, panel không hiển thị:
- `--rdp` tunnel (documented nhưng không parse)
- chntpw password reset (comment block, không implement)
- `WINBOXES_DISK_BUS` selector (định nghĩa nhưng disk luôn virtio-blk)
- foreground service / wake lock (không có)
- PGO/BOLT: build-time QEMU optimization (root-requiring), không phải runtime VM feature —
  panel delegate sang `winboxes.sh --pgo --llvm-bolt` nếu cần.

## Chạy
```bash
bash WinBoxes-Panel.sh
# → hỏi mode (1=Hosting / 2=VM), port
# → mở http://localhost:8090 (web khách hàng — KHÔNG cần login)
```
Non-interactive:
```bash
WINBOXES_PANEL_MODE=hosting WINBOXES_PANEL_PORT=8090 bash WinBoxes-Panel.sh
DEBUG=1 bash WinBoxes-Panel.sh                # debug mode (log HTTP đầy đủ)
```

### Dừng panel (giữ VM chạy)
```bash
bash WinBoxes-Panel.sh --stop     # Dừng web UI — VM vẫn chạy
bash WinBoxes-Panel.sh --status   # Xem panel + VM status
bash WinBoxes-Panel.sh --debug    # Khởi động ở debug mode
bash WinBoxes-Panel.sh --help     # Trợ giúp
```
`--stop` CHỈ dừng web UI (backend Python + node agent heartbeat).
QEMU chạy **daemonized** (process độc lập) nên **KHÔNG bị ảnh hưởng**.
Khởi động lại panel: `bash WinBoxes-Panel.sh` — VM tự xuất hiện lại trên dashboard.

### Node Enrollment (Hosting ↔ VM Mode qua Internet)

**KHÔNG cần enrollment key** — node chỉ cần biết Hosting URL.

**Hosting (Neurodesk):**
```bash
WINBOXES_PANEL_MODE=hosting WINBOXES_PANEL_PORT=8080 bash WinBoxes-Panel.sh
# → Public URL qua Pinggy/Tunnel: ssh -p 443 -R0:localhost:8080 ...@free.pinggy.io
# → Chia sẻ URL Pinggy cho node operator
```

**VM Mode (Colab/VPS):**
```bash
WINBOXES_PANEL_MODE=vm WINBOXES_PANEL_PORT=8090 bash WinBoxes-Panel.sh
# → Nhập Hosting URL (https://xxxxx.pinggy.net — KHÔNG dùng localhost)
# → Lưu lại, không cần nhập lại. Tự đăng ký + heartbeat 5s.
```

Node agent tự động:
1. **Register** (POST /api/node/register) — gửi full payload (CPU/RAM/Disk quota, env, OS, arch...)
2. **Heartbeat** 5s (POST /api/node/heartbeat) — cập nhật CPU/RAM/Disk/VM count
3. **Retry** exponential backoff: 5→10→20→40→60s nếu hosting offline
4. **Auto re-register** khi hosting online lại — không cần restart

**Debug mode:** `DEBUG=1 bash WinBoxes-Panel.sh` — log HTTP request/response, headers, body, retry.

**Hosting log:** `~/.winboxes-panel/logs/hosting.log` — register/heartbeat/offline events.

Đặt `winboxes-stable-3-2.sh` (hoặc `winboxes.sh`) cùng thư mục để panel dùng làm engine
cho build/download. Nếu không có, panel vẫn chạy VM qua launcher riêng (ảnh phải có sẵn).

## noVNC
`console.html` tải `@novnc/novnc` RFB core từ CDN jsdelivr, fallback local
`panel/static/novnc/core/rfb.js` (tải noVNC release vào đó nếu cần offline).
QEMU launcher bật `-vnc :N,websocket=WS` → noVNC kết nối `ws://host:WS` trực tiếp,
không cần websockify riêng.

## Yêu cầu
- `python3` (stdlib only, không pip) — backend
- `bash`, `socat` (cho QMP) — launcher
- `qemu-system-x86_64` + `qemu-img` — để chạy VM (WinBoxes build hoặc system pkg)
- Không cần root. Data trong `$HOME/.winboxes-panel`.
