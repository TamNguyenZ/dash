#!/usr/bin/env bash
# ════════════════════════════════════════════════════════════════════════════
#  WinBoxes-Panel.sh — Web Dashboard điều khiển WinBoxes (cho khách hàng)
#  ----------------------------------------------------------------------------
#  Hai chế độ:
#    1) Hosting Mode — máy chủ chính: lưu trữ VM, scheduler, API, noVNC.
#       Web KHÔNG có login/token — mở cho khách hàng. Hosting operator chia sẻ
#       "node enrollment key" (nội bộ) cho node operator.
#    2) VM Mode      — node chạy trên rootless/container/JupyterHub, đăng ký
#                      lên Hosting bằng enrollment key, nhận lệnh tạo VM.
#
#  KHÔNG có admin role, KHÔNG có customer token. Web thuần cho khách hàng.
#  Node<->Hosting dùng shared secret nội bộ (enrollment key) — khách không thấy.
# ════════════════════════════════════════════════════════════════════════════
set -uo pipefail

if [ -t 1 ]; then
    G='\033[1;32m'; Y='\033[1;33m'; R='\033[1;31m'; B='\033[1;34m'; C='\033[1;36m'; W='\033[0m'; BOLD='\033[1m'
else
    G=''; Y=''; R=''; B=''; C=''; W=''; BOLD=''
fi
ok(){   printf "${G}✔${W} %s\n" "$*"; }
inf(){  printf "${B}ℹ${W}  %s\n" "$*"; }
warn(){ printf "${Y}⚠${W}  %s\n" "$*"; }
err(){  printf "${R}✘${W} %s\n" "$*" >&2; }
hdr(){  printf "\n${C}═══ %s ═══${W}\n" "$*"; }

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PANEL_DIR="${SCRIPT_DIR}/panel"
BACKEND="${PANEL_DIR}/backend.py"
LAUNCHER="${PANEL_DIR}/qemu_launcher.sh"
DATA_DIR="${WINBOXES_PANEL_HOME:-${HOME}/.winboxes-panel}"
mkdir -p "$DATA_DIR" "${DATA_DIR}/vm" "${DATA_DIR}/logs" "${DATA_DIR}/nodes"

MODE_FILE="${DATA_DIR}/mode"
NODE_KEY_FILE="${DATA_DIR}/node_key"      # shared secret node↔hosting (nội bộ)
HOSTING_FILE="${DATA_DIR}/hosting"        # cho VM mode: URL hosting + enrollment key
PORT_FILE="${DATA_DIR}/port"
DEFAULT_PORT="${WINBOXES_PANEL_PORT:-8090}"

WINBOX_ENGINE_URL="https://raw.githubusercontent.com/assassin255/WinBoxes-Source/refs/heads/main/winboxes-stable-3-2.sh"

# ── PHÁT HIỆN MÔI TRƯỜNG ────────────────────────────────────────────────────
detect_env() {
    local env="host" rootless=0
    [ "$(id -u)" != "0" ] && rootless=1
    [ -f /.dockerenv ] && env="docker"
    grep -qaE 'docker|containerd|kubepods|lxc' /proc/1/cgroup 2>/dev/null && env="container"
    grep -qa 'container=' /proc/1/environ 2>/dev/null && env="lxc"
    [ -n "${KUBERNETES_SERVICE_HOST:-}" ] && env="k8s"
    [ -n "${JUPYTERHUB_USER:-}" ] && env="${env}+jupyterhub"
    echo "${env}|rootless=${rootless}"
}

# ── SINH NODE ENROLLMENT KEY (chỉ hosting mode, nội bộ) ─────────────────────
ensure_node_key() {
    if [ -f "$NODE_KEY_FILE" ] && [ -s "$NODE_KEY_FILE" ]; then return 0; fi
    if command -v openssl >/dev/null 2>&1; then
        openssl rand -hex 24 > "$NODE_KEY_FILE" 2>/dev/null
    elif [ -r /dev/urandom ]; then
        head -c 24 /dev/urandom | od -An -tx1 | tr -d ' \n' > "$NODE_KEY_FILE"
    else
        date +%s%N | sha256sum | awk '{print $1}' > "$NODE_KEY_FILE"
    fi
    chmod 600 "$NODE_KEY_FILE" 2>/dev/null || true
}

# ── CHỌN MODE ───────────────────────────────────────────────────────────────
select_mode() {
    hdr "Select Running Mode" >&2
    echo "  1) Hosting Mode  — Máy chủ chính (lưu VM, scheduler, API cho khách)" >&2
    echo "  2) VM Mode       — Node (rootless/container/JupyterHub), đăng ký lên Hosting" >&2
    echo >&2
    local choice
    if [ -n "${WINBOXES_PANEL_MODE:-}" ]; then
        choice="$WINBOXES_PANEL_MODE"
    else
        printf "${BOLD}Chọn [1/2]${W}: " >&2
        read -r choice 2>/dev/null || choice="1"
    fi
    case "$choice" in
        1|hosting|Hosting) echo "hosting" ;;
        2|vm|VM)           echo "vm" ;;
        *) warn "Mặc định: Hosting Mode" >&2; echo "hosting" ;;
    esac
}

# ── VM MODE: HỎI ĐĂNG KÝ HOSTING ─────────────────────────────────────────────
ask_register_hosting() {
    hdr "Đăng ký Node lên Hosting" >&2
    echo "Đăng ký máy này thành Node cho Hosting." >&2
    echo "  - Cần URL Hosting CÔNG KHAI (vd: https://xxxxx.a.free.pinggy.link)" >&2
    echo "  - KHÔNG dùng localhost/127.0.0.1 nếu Hosting ở máy khác!" >&2
    echo "  - Cần Node Enrollment Key (hỏi Hosting operator)" >&2
    echo "  - Để trống URL nếu chạy độc lập" >&2
    echo >&2
    printf "${BOLD}Hosting URL${W} [Enter để bỏ qua]: " >&2
    read -r url 2>/dev/null || url=""
    if [ -z "$url" ]; then
        warn "Chạy VM Mode độc lập (chưa gắn Hosting)." >&2
        return 0
    fi
    # Validate: warn nếu dùng localhost
    case "$url" in
        localhost*|127.0.0.1*|http://localhost*|https://localhost*)
            warn "URL chứa localhost — chỉ hoạt động nếu Hosting cùng máy!" >&2
            printf "${BOLD}Chắc chứ? [y/N]${W}: " >&2
            read -r confirm 2>/dev/null || confirm=""
            [ "$confirm" != "y" ] && [ "$confirm" != "Y" ] && { warn "Bỏ qua đăng ký." >&2; return 0; }
            ;;
    esac
    printf "${BOLD}Node Enrollment Key${W}: " >&2
    read -rs nkey 2>/dev/null || nkey=""
    echo >&2
    if [ -z "$nkey" ]; then
        err "Enrollment Key không được để trống!" >&2
        return 1
    fi
    printf "%s\n%s\n" "$url" "$nkey" > "$HOSTING_FILE"
    chmod 600 "$HOSTING_FILE" 2>/dev/null || true
    ok "Đã lưu Hosting URL: $url" >&2
    ok "Enrollment Key: ${nkey:0:8}••••••••••••" >&2
    inf "Node sẽ tự đăng ký + gửi heartbeat 5s khi khởi động." >&2
    inf "Nếu Hosting offline → retry 5→10→20→40→60s (exponential backoff)." >&2
}

# ── TÌM / TẢI ENGINE WINBOXES.SH ─────────────────────────────────────────────
find_or_download_engine() {
    local winbox=""
    for p in "${SCRIPT_DIR}/winboxes-stable-3-2.sh" "${SCRIPT_DIR}/winboxes.sh" \
             "${SCRIPT_DIR}/winbox.sh" "${DATA_DIR}/winboxes-stable-3-2.sh" \
             "$(command -v winboxes.sh 2>/dev/null)" \
             "$(command -v winbox.sh 2>/dev/null)"; do
        [ -n "$p" ] && [ -f "$p" ] && { winbox="$p"; break; }
    done
    [ -n "$winbox" ] && { echo "$winbox"; return 0; }

    warn "Không tìm thấy winboxes-stable-3-2.sh (engine) ở local." >&2
    local dl="n"
    if [ "${WINBOXES_PANEL_AUTO_DL_ENGINE:-1}" = "1" ]; then dl="y"
    elif [ -t 0 ]; then
        printf "${BOLD}Tải engine winboxes-stable-3-2.sh từ GitHub?${W} [Y/n]: " >&2
        read -r dl 2>/dev/null || dl="y"
    fi
    case "$dl" in
        n|N|"")
            warn "Bỏ qua engine. Panel chạy với QEMU launcher (cần QEMU đã cài sẵn)." >&2
            echo ""; return 1 ;;
    esac
    local dest="${DATA_DIR}/winboxes-stable-3-2.sh"
    inf "Tải engine script từ GitHub (CHỈ bash script, KHÔNG tải ảnh Windows)..." >&2
    local ok_dl=0
    command -v curl >/dev/null 2>&1 && curl -fsSL "$WINBOX_ENGINE_URL" -o "$dest" 2>/dev/null && ok_dl=1
    [ "$ok_dl" != "1" ] && command -v wget >/dev/null 2>&1 && wget -q "$WINBOX_ENGINE_URL" -O "$dest" 2>/dev/null && ok_dl=1
    [ "$ok_dl" != "1" ] && python3 -c "import urllib.request;urllib.request.urlretrieve('$WINBOX_ENGINE_URL','$dest')" 2>/dev/null && ok_dl=1
    if [ "$ok_dl" = "1" ] && [ "$(stat -c%s "$dest" 2>/dev/null || echo 0)" -gt 1000 ]; then
        chmod +x "$dest" 2>/dev/null || true
        ok "Đã tải engine: $dest" >&2
        echo "$dest"; return 0
    else
        err "Tải engine thất bại: $WINBOX_ENGINE_URL" >&2
        warn "Panel vẫn chạy với QEMU launcher (nếu QEMU đã cài sẵn)." >&2
        echo ""; return 1
    fi
}

# ── ĐẢM BẢO CÓ PYTHON3 ──────────────────────────────────────────────────────
ensure_python() {
    command -v python3 >/dev/null 2>&1 && return 0
    err "Cần python3. Cài: apt install python3 / conda install python"
    return 1
}

# ── TÌM PANEL PID (PID file hoặc scan /proc) ─────────────────────────────────
_find_panel_pids() {
    # 1. Thử PID file (nơi panel mới ghi)
    local pf="${DATA_DIR}/panel.pid"
    if [ -f "$pf" ]; then
        local pid; pid="$(cat "$pf" 2>/dev/null || true)"
        if [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null && \
           grep -qa "backend.py" "/proc/$pid/cmdline" 2>/dev/null; then
            echo "$pid"
            return 0
        fi
    fi
    # 2. Scan /proc tìm mọi process backend.py (xử lý panel chạy bằng user khác,
    #    code cũ không ghi PID file, hoặc WINBOXES_PANEL_HOME khác)
    local found=""
    for p in /proc/[0-9]*; do
        local pid="${p##*/}"
        if grep -qa "backend.py" "/proc/$pid/cmdline" 2>/dev/null; then
            found="$found $pid"
        fi
    done
    echo "${found# }"
}

# ── DỪNG PANEL (giữ VM chạy) ─────────────────────────────────────────────────
# QEMU chạy daemonized (process riêng) → kill panel KHÔNG ảnh hưởng VM.
# Panel dừng = dừng web UI + node agent heartbeat. VM vẫn chạy bình thường.
# Khởi động lại panel: `bash WinBoxes-Panel.sh` — VM sẽ tự xuất hiện lại.
stop_panel() {
    hdr "Dừng WinBoxes-Panel (giữ VM chạy)"
    local pids; pids="$(_find_panel_pids)"
    if [ -z "$pids" ]; then
        warn "Panel không chạy (không tìm thấy process backend.py)"
        _show_vm_status
        exit 0
    fi
    # Dừng từng PID (có thể nhiều instance nếu chạy nhiều port)
    local pid
    for pid in $pids; do
        if ! kill -0 "$pid" 2>/dev/null; then continue; fi
        local port="?"
        # Cố gắng đọc port từ environ
        [ -r "/proc/$pid/environ" ] && \
            port="$(tr '\0' '\n' < "/proc/$pid/environ" 2>/dev/null | grep '^WINBOXES_PANEL_PORT=' | cut -d= -f2)"
        inf "Gửi SIGTERM tới panel (PID $pid, port ${port:-?}) — VM sẽ KHÔNG bị dừng"
        kill -TERM "$pid" 2>/dev/null || true
        local i
        for i in $(seq 1 20); do
            kill -0 "$pid" 2>/dev/null || break
            sleep 0.3
        done
        if kill -0 "$pid" 2>/dev/null; then
            warn "Graceful timeout — SIGKILL (PID $pid)"
            kill -9 "$pid" 2>/dev/null || true
        fi
        ok "Panel PID $pid đã dừng."
    done
    # Dọn PID file (nếu có, có thể stale)
    rm -f "${DATA_DIR}/panel.pid" 2>/dev/null
    _show_vm_status
    exit 0
}

# ── HIỂN THỊ TRẠNG THÁI VM ───────────────────────────────────────────────────
_show_vm_status() {
    local vm_run=0 vpid
    # Scan PID files trong data dir
    for vf in "${DATA_DIR}/vm"/vm_*.pid; do
        [ -f "$vf" ] || continue
        vpid="$(cat "$vf" 2>/dev/null || true)"
        [ -n "$vpid" ] && kill -0 "$vpid" 2>/dev/null && vm_run=$((vm_run+1))
    done
    # Cũng scan /proc cho qemu-system (xử lý data dir khác)
    # Chỉ đếm process mà cmdline[0] chứa qemu-system (tránh match grep/shell)
    local qemu_count=0
    for p in /proc/[0-9]*; do
        local pid="${p##*/}"
        [ -r "/proc/$pid/cmdline" ] || continue
        local first_arg; first_arg="$(tr '\0' '\n' < "/proc/$pid/cmdline" 2>/dev/null | head -1)"
        case "$first_arg" in
            *qemu-system*) qemu_count=$((qemu_count+1)) ;;
        esac
    done
    vm_run=$((vm_run + qemu_count))
    if [ "$vm_run" -gt 0 ]; then
        ok "${vm_run} VM đang chạy (KHÔNG bị ảnh hưởng)"
        inf "Khởi động lại panel: bash WinBoxes-Panel.sh"
    else
        inf "Không có VM nào đang chạy."
    fi
}

# ── TRẠNG THÁI PANEL ─────────────────────────────────────────────────────────
status_panel() {
    hdr "WinBoxes-Panel Status"
    local pids; pids="$(_find_panel_pids)"
    if [ -n "$pids" ]; then
        local pid
        for pid in $pids; do
            local port="?"
            [ -r "/proc/$pid/environ" ] && \
                port="$(tr '\0' '\n' < "/proc/$pid/environ" 2>/dev/null | grep '^WINBOXES_PANEL_PORT=' | cut -d= -f2)"
            ok "Panel đang chạy (PID $pid, port ${port:-?})"
        done
    else
        warn "Panel không chạy"
    fi
    _show_vm_status
    exit 0
}

# ── HELP ──────────────────────────────────────────────────────
show_help() {
    hdr "WinBoxes-Panel — Usage"
    cat <<EOF
  bash WinBoxes-Panel.sh            Khởi động panel (interactive)
  bash WinBoxes-Panel.sh --debug    Khởi động ở debug mode (log HTTP đầy đủ)
  bash WinBoxes-Panel.sh --stop     Dừng panel — VM vẫn chạy
  bash WinBoxes-Panel.sh --status   Trạng thái panel + VM
  bash WinBoxes-Panel.sh --help     Hiển thị trợ giúp này

Non-interactive:
  WINBOXES_PANEL_MODE=hosting WINBOXES_PANEL_PORT=8090 bash WinBoxes-Panel.sh
  DEBUG=1 bash WinBoxes-Panel.sh    # tương đương --debug

Lưu ý: --stop CHỈ dừng web UI, KHÔNG dừng VM.
       QEMU chạy daemonized nên độc lập với panel.
       Khởi động lại panel: bash WinBoxes-Panel.sh — VM tự xuất hiện lại.
       --debug / DEBUG=1: log HTTP request/response, headers, body, retry.
EOF
    exit 0
}

# ── KHỞI ĐỘNG BACKEND ───────────────────────────────────────────────────────
start_backend() {
    local mode="$1" port="$2"
    ensure_python || exit 1
    [ -f "$BACKEND" ] || { err "Thiếu backend: $BACKEND"; exit 1; }

    ensure_node_key   # sinh node enrollment key (nội bộ, hosting mode dùng)

    export WINBOXES_PANEL_MODE="$mode"
    export WINBOXES_PANEL_DATA="$DATA_DIR"
    export WINBOXES_PANEL_PORT="$port"
    export WINBOXES_PANEL_SCRIPT_DIR="$SCRIPT_DIR"
    export WINBOXES_PANEL_LAUNCHER="$LAUNCHER"
    export WINBOXES_PANEL_NODE_KEY="$(cat "$NODE_KEY_FILE" 2>/dev/null)"
    [ -f "$HOSTING_FILE" ] && export WINBOXES_PANEL_HOSTING_FILE="$HOSTING_FILE"
    [ -n "${WINBOXES_PANEL_DEBUG:-}" ] && export WINBOXES_PANEL_DEBUG

    local winbox=""
    winbox="$(find_or_download_engine)" || true
    export WINBOXES_PANEL_WINBOX="${winbox:-}"
    [ -n "$winbox" ] && inf "Engine WinBoxes: $winbox"

    hdr "Khởi động WinBoxes-Panel"
    inf "Mode        : $([ "$mode" = "hosting" ] && echo "Hosting" || echo "VM (Node)")"
    inf "Port        : $port"
    inf "Data dir    : $DATA_DIR"
    inf "Environment : $(detect_env)"
    echo
    printf "${G}➜${W}  Mở trình duyệt: ${BOLD}http://localhost:%s${W}\n" "$port"
    printf "${G}➜${W}  Web cho khách hàng — KHÔNG cần đăng nhập/token.\n"
    if [ "$mode" = "hosting" ]; then
        echo
        printf "${Y}➜${W}  Node Enrollment Key (chia sẻ cho node operator, KHÔNG cho khách):\n"
        printf "    ${BOLD}%s${W}\n" "$(cat "$NODE_KEY_FILE")"
        printf "    (dùng khi đăng ký VM Mode node lên hosting này)\n"
    fi
    echo
    printf "${Y}Ctrl+C để dừng panel.${W}  ${Y}Hoặc:${W} bash WinBoxes-Panel.sh --stop (VM vẫn chạy)\n\n"

    # exec: shell thay bằng python — Python tự xử lý SIGTERM/SIGINT + PID file.
    # QEMU daemonized nên độc lập, panel dừng không ảnh hưởng VM.
    exec python3 "$BACKEND"
}

# ── MAIN ───────────────────────────────────────────────────────────────────
main() {
    hdr "WinBoxes-Panel"
    inf "Environment: $(detect_env)"

    local mode=""
    if [ -f "$MODE_FILE" ] && [ -s "$MODE_FILE" ]; then
        mode="$(cat "$MODE_FILE")"
        inf "Mode đã lưu: $mode (xoá $MODE_FILE để chọn lại)"
    else
        mode="$(select_mode)"
        echo "$mode" > "$MODE_FILE"
    fi

    if [ "$mode" = "vm" ] && [ ! -f "$HOSTING_FILE" ]; then
        ask_register_hosting
    fi

    local port="${WINBOXES_PANEL_PORT:-$(cat "$PORT_FILE" 2>/dev/null || echo "$DEFAULT_PORT")}"
    if [ -z "${WINBOXES_PANEL_PORT:-}" ]; then
        printf "${BOLD}Port panel${W} [$port]: " >&2
        read -r p 2>/dev/null || p=""
        [ -n "$p" ] && port="$p"
        echo "$port" > "$PORT_FILE"
    fi

    start_backend "$mode" "$port"
}

# ── PARSE ARGS ───────────────────────────────────────────────────────────────
case "${1:-}" in
    --stop)   stop_panel ;;
    --status) status_panel ;;
    --help|-h) show_help ;;
    --debug)  export WINBOXES_PANEL_DEBUG=1; shift ;;
esac

# DEBUG=1 env var cũng bật debug mode
[ "${DEBUG:-0}" = "1" ] && export WINBOXES_PANEL_DEBUG=1

main "$@"
